﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.model
{
    public class MedicareServices
    {
        private long _medicareServiceId;
        private string _medicareServiceName;
        private string _medicareDescription;
        private long _medicareAmount;

        public MedicareServices()
        {

        }

        public MedicareServices(long _medicareServiceId, string _medicareServiceName, string _medicareDescription, long _medicareAmount)
        {
            this.MedicareServiceId = _medicareServiceId;
            this.MedicareServiceName = _medicareServiceName;
            this.MedicareDescription = _medicareDescription;
            this.MedicareAmount = _medicareAmount;
        }

        public long MedicareServiceId
        {
            get
            {
                return _medicareServiceId;
            }

            set
            {
                _medicareServiceId = value;
            }
        }

        public string MedicareServiceName
        {
            get
            {
                return _medicareServiceName;
            }

            set
            {
                _medicareServiceName = value;
            }
        }

        public string MedicareDescription
        {
            get
            {
                return _medicareDescription;
            }

            set
            {
                _medicareDescription = value;
            }
        }

        public long MedicareAmount
        {
            get
            {
                return _medicareAmount;
            }

            set
            {
                _medicareAmount = value;
            }
        }
    }
}
