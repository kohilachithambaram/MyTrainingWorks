﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.model {
    public class Doctor {
        private string _doctorId;
        private string _firstName;
        private string _lastName;
        private int _age;
        private string _gender;
        private string _dateOfBirth;
        private long _phone;
        private long _alternatePhone;
        private string _email;
        private string _password;
        private string _addressLine1;
        private string _addressLine2;
        private string _city;
        private string _state;
        private long _zipcode;
        private string _degree;
        private string _speciality;
        private long _workHours;
        private string _clinicName;
        private long _medicareServiceId;
        private string _doctorStatus;

        public Doctor()
        {

        }

        public Doctor(string _doctorId, string _firstName, string _lastName, int _age, string _gender, string _dateOfBirth, long _phone, long _alternatePhone, string _email, string _password, string _addressLine1, string _addressLine2, string _city, string _state, long _zipcode, string _degree, string _speciality, long _workHours, string _clinicName, long _medicareServiceId, string _doctorStatus)
        {
            this._doctorId = _doctorId;
            this._firstName = _firstName;
            this._lastName = _lastName;
            this._age = _age;
            this._gender = _gender;
            this._dateOfBirth = _dateOfBirth;
            this._phone = _phone;
            this._alternatePhone = _alternatePhone;
            this._email = _email;
            this._password = _password;
            this._addressLine1 = _addressLine1;
            this._addressLine2 = _addressLine2;
            this._city = _city;
            this._state = _state;
            this._zipcode = _zipcode;
            this._degree = _degree;
            this._speciality = _speciality;
            this._workHours = _workHours;
            this._clinicName = _clinicName;
            this._medicareServiceId = _medicareServiceId;
            this._doctorStatus = _doctorStatus;
        }

        public string DoctorId {
            get {
                return _doctorId;
            }

            set {
                _doctorId = value;
            }
        }

        public string FirstName {
            get {
                return _firstName;
            }

            set {
                _firstName = value;
            }
        }

        public string LastName {
            get {
                return _lastName;
            }

            set {
                _lastName = value;
            }
        }

        public int Age {
            get {
                return _age;
            }

            set {
                _age = value;
            }
        }

        public string Gender {
            get {
                return _gender;
            }

            set {
                _gender = value;
            }
        }

        public string DateOfBirth {
            get {
                return _dateOfBirth;
            }

            set {
                _dateOfBirth = value;
            }
        }

        public long Phone {
            get {
                return _phone;
            }

            set {
                _phone = value;
            }
        }

        public long AlternatePhone {
            get {
                return _alternatePhone;
            }

            set {
                _alternatePhone = value;
            }
        }

        public string Email {
            get {
                return _email;
            }

            set {
                _email = value;
            }
        }

        public string Password {
            get {
                return _password;
            }

            set {
                _password = value;
            }
        }

        public string AddressLine1 {
            get {
                return _addressLine1;
            }

            set {
                _addressLine1 = value;
            }
        }

        public string AddressLine2 {
            get {
                return _addressLine2;
            }

            set {
                _addressLine2 = value;
            }
        }

        public string City {
            get {
                return _city;
            }

            set {
                _city = value;
            }
        }

        public string State {
            get {
                return _state;
            }

            set {
                _state = value;
            }
        }

        public long Zipcode {
            get {
                return _zipcode;
            }

            set {
                _zipcode = value;
            }
        }

        public string Degree {
            get {
                return _degree;
            }

            set {
                _degree = value;
            }
        }

        public string Speciality {
            get {
                return _speciality;
            }

            set {
                _speciality = value;
            }
        }

        public long WorkHours {
            get {
                return _workHours;
            }

            set {
                _workHours = value;
            }
        }

        public string ClinicName {
            get {
                return _clinicName;
            }

            set {
                _clinicName = value;
            }
        }

        public long MedicareServiceId {
            get {
                return _medicareServiceId;
            }

            set {
                _medicareServiceId = value;
            }
        }

        public string DoctorStatus {
            get {
                return _doctorStatus;
            }

            set {
                _doctorStatus = value;
            }
        }
    }
}
