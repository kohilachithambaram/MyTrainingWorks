﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
using System.Data;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        string patientId = Session["patientId"].ToString();
        string patientName = Session["patientName"].ToString();
        if (patientId == null || patientName == null)
        {
            Response.Redirect("ErrorPage.aspx");
        }
        else {
            lblPatientId.Text = patientName + " " + "[" + patientId + "]";
            bookingPanel.Visible = false;
            viewAppointmentPanel.Visible = false;
            viewPatientReportPanel.Visible = false;
            lblDocEmpty.Visible = false;
            lblAppEmpty.Visible = false;
        }
    }

    protected void GridPatientBookAppointmentClick(object sender, GridViewCommandEventArgs e) {
        int gridViewRowIndex = int.Parse(e.CommandArgument.ToString());
        string doctorId = gridBookAppointment.Rows[gridViewRowIndex].Cells[0].Text;
        Session["doctorId"] = doctorId;
        Response.Redirect("BookAppointment.aspx");
    }

    protected void btnBookAppointment_Click(object sender, EventArgs e) {
        try {
            bookingPanel.Visible = true;
            DisplayDoctorDetails();
        }
        catch (Exception) {
            Response.Redirect("ErrorPage.aspx");
        }
    }

    protected void DisplayDoctorDetails() {
        try {
            DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
            List<Doctor> doctorList = doctorDao.GetDoctorList();
            gridBookAppointment.DataSource = doctorList;
            gridBookAppointment.DataBind();
        }
        catch (AppointmentEmptyException exception) {
            lblDocEmpty.Text = exception.ToString();
            lblDocEmpty.Visible = true;
        }
    }

    protected void btnViewAppointment_Click(object sender, EventArgs e) {
        try {
            viewAppointmentPanel.Visible = true;
            ViewDoctorDetails();
        }
        catch (Exception) {
            Response.Redirect("ErrorPage.aspx");
        }
    }

    protected void ViewDoctorDetails() {
        try {
            AppointmentDaoSqlImpl appointmentDao = new AppointmentDaoSqlImpl();
            string patientId = Session["patientId"].ToString();
            List<Appointment> appointmentList = appointmentDao.ViewPatientAppointments(patientId);
            gridViewAppointment.DataSource = appointmentList;
            gridViewAppointment.DataBind();
        }
        catch (AppointmentEmptyException exception) {
            lblAppEmpty.Text = exception.ToString();
            lblAppEmpty.Visible = true;
        }
    }

    protected void btnViewReport_Click(object sender, EventArgs e) {
        try
        {
            viewPatientReportPanel.Visible = true;
        }
        catch (Exception exeception)
        {
            Response.Write(exeception.Message);
        }
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            Session["doctorId"] = txtDocId.Text;
            Session["apDate"] = txtApDate.Text;
            Response.Redirect("ViewMedicalReportPatient.aspx");
        }
        catch (Exception exeception)
        {
            Response.Write(exeception.Message);
        }
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            viewPatientReportPanel.Visible = true;
            txtApDate.Text = "";
            txtDocId.Text = "";
            txtDocId.Focus();
        }
        catch (Exception exeception)
        {
            Response.Write(exeception.Message);
        }
    }
}