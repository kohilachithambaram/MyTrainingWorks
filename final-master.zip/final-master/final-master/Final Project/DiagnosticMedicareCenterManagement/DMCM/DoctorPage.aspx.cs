﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
using com.cognizant.dmcm.util;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string doctorId = Session["doctorId"].ToString();
        string doctorName = Session["doctorName"].ToString();
        if (doctorId == null || doctorName == null)
        {
            Response.Redirect("ErrorPage.aspx");
        }
        else
        {
            lblDoctorId.Text = "Dr." + doctorName + " " + "[" + doctorId + "]";
            viewingPanel.Visible = false;
            MedicarePanel.Visible = false;
            viewReport.Visible = false;
            generateReport.Visible = false;
            lblAppEmpty1.Visible = false;
            lblAppEmpty2.Visible = false;
            lblAppEmpty3.Visible = false;
        }
    }
    protected void DisplayAppointmentPatientDetails()

    {
        try
        {

            AppointmentDaoSqlImpl appointmentDao = new AppointmentDaoSqlImpl();

            string doctorId = Session["doctorId"].ToString();
            List<Patient> patientList = appointmentDao.ViewDoctorAppointments(doctorId);

            gridAcceptAppointment.DataSource = patientList;

            gridAcceptAppointment.DataBind();
    }
        catch (AppointmentEmptyException exception)
        {
            lblAppEmpty1.Text = exception.ToString();
            lblAppEmpty1.Visible = true;
        }

    }
    protected void btnViewAppointment_Click(object sender, EventArgs e)
    {
        try
        {
            MedicarePanel.Visible = false;
            viewReport.Visible = false;
            generateReport.Visible = false;
            viewingPanel.Visible = true;
            lblAppEmpty1.Visible = false;
            lblAppEmpty2.Visible = false;
            lblAppEmpty3.Visible = false;

            DisplayAppointmentPatientDetails();
    }
        catch (Exception)
        {
            Response.Redirect("ErrorPage.aspx");
        }

    }



    protected void GridPatientAcceptAppointmentClick(object sender, GridViewCommandEventArgs e)

    {

        if (e.CommandName == "AcceptAppointment")

        {

            int gridViewRowIndex = int.Parse(e.CommandArgument.ToString());

            if (gridAcceptAppointment.Rows[gridViewRowIndex].Cells[4].Text == "Approved")

            {

                Response.Write("<script>alert('Already Approved');window.location.href='DoctorPage.aspx'</script>");

            }

            else

            {

                gridAcceptAppointment.Rows[gridViewRowIndex].Cells[4].Text = "Approved";

                string patientId = gridAcceptAppointment.Rows[gridViewRowIndex].Cells[0].Text;

                string status = gridAcceptAppointment.Rows[gridViewRowIndex].Cells[4].Text;
                DateTime date = DateUtil.convertToDate(gridAcceptAppointment.Rows[gridViewRowIndex].Cells[3].Text);
                string reportStatus = "Unavailable";
                AppointmentDaoSqlImpl appointmentDao = new AppointmentDaoSqlImpl();
                string doctorId = Session["doctorId"].ToString();
                appointmentDao.ModifyAppointmentStatus(reportStatus, status, patientId, doctorId,date);

            }

        }

        if (e.CommandName == "RejectAppointment")

        {

            int gridViewRowIndex = int.Parse(e.CommandArgument.ToString());

            
            if (gridAcceptAppointment.Rows[gridViewRowIndex].Cells[4].Text == "Rejected")
            {

                Response.Write("<script>alert('Already Rejected');window.location.href='DoctorPage.aspx'</script>");

            }
            else if(gridAcceptAppointment.Rows[gridViewRowIndex].Cells[4].Text == "Approved")
            {
                Response.Write("<script>alert('You cannot reject the approved patient');window.location.href='DoctorPage.aspx'</script>");
            }

            else

            {

                gridAcceptAppointment.Rows[gridViewRowIndex].Cells[4].Text = "Rejected";

                string patientId = gridAcceptAppointment.Rows[gridViewRowIndex].Cells[0].Text;

                string status = gridAcceptAppointment.Rows[gridViewRowIndex].Cells[4].Text;
                DateTime date = DateUtil.convertToDate(gridAcceptAppointment.Rows[gridViewRowIndex].Cells[3].Text);
                string reportStatus = "Not Available";
                AppointmentDaoSqlImpl appointmentDao = new AppointmentDaoSqlImpl();
                string doctorId = Session["doctorId"].ToString();
                appointmentDao.ModifyAppointmentStatus(reportStatus,status, patientId, doctorId, date);

            }

        }

    }



    protected void btnViewMedicareService_Click(object sender, EventArgs e)
    {
        try
        {
            viewingPanel.Visible = false;
            generateReport.Visible = false;
            viewReport.Visible = false;
            MedicarePanel.Visible = true;
            DisplayMedicareServices();
            lblAppEmpty1.Visible = false;
            lblAppEmpty2.Visible = false;
            lblAppEmpty3.Visible = false;
        }
        catch (Exception)
        {
            Response.Redirect("ErrorPage.aspx");
        }

    }
    protected void DisplayMedicareServices()
    {
        try
        {
            MedicareServiceDaoSqlImpl medicareServiceDao = new MedicareServiceDaoSqlImpl();
            List<MedicareServices> medicareServiceList = medicareServiceDao.GetAllMedicareServices();
            gridMedicareServices.DataSource = medicareServiceList;
            gridMedicareServices.DataBind();
        }
        catch (Exception)
        {
            Response.Redirect("ErrorPage.aspx");
        }


    }

    protected void btnViewReport_Click(object sender, EventArgs e)
    {
        try
        {
            viewingPanel.Visible = false;
            generateReport.Visible = false;
            MedicarePanel.Visible = false;
            viewReport.Visible = true;
            DisplayPatientDetails();
            lblAppEmpty1.Visible = false;
            
            lblAppEmpty3.Visible = false;
        }
        catch (Exception)
        {
            Response.Redirect("ErrorPage.aspx");
        }
    }

    protected void DisplayPatientDetails()
    {
        try
        {
            PatientDaoSqlImpl patientDaoSqlImpl = new PatientDaoSqlImpl();
            string doctorId = Session["doctorId"].ToString();
            List<Patient> patientList = patientDaoSqlImpl.DisplayAvailablePatientReport(doctorId);
            gridReport.DataSource = patientList;
            gridReport.DataBind();
        }
        catch (AppointmentEmptyException exception)
        {
            lblAppEmpty2.Text = exception.ToString();
            lblAppEmpty2.Visible = true;
            gridReport.Visible = false;
        }

    }

    protected void gridReport_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "details")
        {
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            string patientId = gridReport.Rows[gridviewrowindex].Cells[0].Text;
            Session["patientId"] = patientId;
            Response.Redirect("PatientDetails.aspx");

        }
        if (e.CommandName == "report")
        {
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            string patientId = gridReport.Rows[gridviewrowindex].Cells[0].Text;
            DateTime appointmentDate = DateUtil.convertToDate(gridReport.Rows[gridviewrowindex].Cells[5].Text);
            Session["patientId"] = patientId;
            Session["apDate"] = appointmentDate.ToString();
            Response.Redirect("ViewMedicalReport.aspx");

        }
        if (e.CommandName == "updateReport")
        {
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            string patientId = gridReport.Rows[gridviewrowindex].Cells[0].Text;
            DateTime appointmentDate = DateUtil.convertToDate(gridReport.Rows[gridviewrowindex].Cells[5].Text);
            Session["patientId"] = patientId;
            Session["apDate"] = appointmentDate.ToString();
            Response.Redirect("UpdateMedicalReport.aspx");

        }
    }

    protected void gridGenerateReport_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "details")
        {
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            string patientId = gridGenerateReport.Rows[gridviewrowindex].Cells[0].Text;
            Session["patientId"] = patientId;
            Response.Redirect("PatientDetails.aspx");

        }
        if (e.CommandName == "generateReport")
        {
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            string patientId = gridGenerateReport.Rows[gridviewrowindex].Cells[0].Text;
            DateTime appointmentDate = DateUtil.convertToDate(gridGenerateReport.Rows[gridviewrowindex].Cells[5].Text);
            Session["patientId"] = patientId;
            Session["apDate"] = appointmentDate.ToString();
            Response.Redirect("MedicalTestReport.aspx");

        }
    }

    protected void DisplayPatientDetailsReport()
    {
        try
        {
            PatientDaoSqlImpl patientDaoSqlImpl = new PatientDaoSqlImpl();
            string doctorId = Session["doctorId"].ToString();
            List<Patient> patientList = patientDaoSqlImpl.DisplayUnavailablePatientReport(doctorId);
            gridGenerateReport.DataSource = patientList;
            gridGenerateReport.DataBind();
        }
        catch (AppointmentEmptyException exception)
        {
            lblAppEmpty3.Text = exception.ToString();
            lblAppEmpty3.Visible = true;

        }

    }

    protected void btnGenerateReport_Click(object sender, EventArgs e)
    {
        try
        {
            viewingPanel.Visible = false;
            MedicarePanel.Visible = false;
            viewReport.Visible = false;
            generateReport.Visible = true;
            DisplayPatientDetailsReport();
            lblAppEmpty1.Visible = false;
            lblAppEmpty2.Visible = false;
            
        }
        catch (Exception)
        {
            Response.Redirect("ErrorPage.aspx");
        }
    }

}