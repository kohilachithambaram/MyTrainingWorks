﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
using com.cognizant.dmcm.util;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            ddlGender.Items.Add("Select Gender");
            ddlGender.Items.Add("Male");
            ddlGender.Items.Add("Female");


            List<string> ageList = new List<string>();
            for (int age = 25; age <= 85; age++)
            {
                ageList.Add(age.ToString());
            }

            ddlAge.DataSource = ageList;
            ddlAge.DataBind();
            ddlAge.Items.Insert(0, "Select Age");
        }
    }

    protected void btnAdminRegister_Click(object sender, EventArgs e) {
        try
        {
            AdminDaoSqlImpl adminDao = new AdminDaoSqlImpl();
            Admin admin = new Admin();
            admin.FirstName = txtFirstName.Text;
            admin.LastName = txtLastName.Text;
            admin.Age = int.Parse(ddlAge.SelectedItem.Text);
            admin.Gender = ddlGender.SelectedItem.Text;
            admin.DateOfBirth = txtDob.Text;
            admin.Phone = long.Parse(txtContactNum.Text);
            if (txtAltNum.Text == "")
            {
                admin.AlternatePhone = 0;
            }
            else
            {
                admin.AlternatePhone = long.Parse(txtAltNum.Text);
            }
            admin.Email = txtEmail.Text;
            admin.Password = txtPassword.Text;

            if (adminDao.AdminRegistration(admin) == 1)
            {
                Response.Write("<script>alert('Registration Successful');window.location.href='Home.aspx'</script>");
            }
            else if (adminDao.AdminRegistration(admin) == 2)
            {
                Response.Write("<script>alert('Email Already taken.Register with new Email');</script>");
            }
            else if (adminDao.AdminRegistration(admin) == 3)
            {
                Response.Write("<script>alert('Alternate number should be different');</script>");
            }
            else
            {
                Response.Write("<script>alert('Registration Failed');window.location.href='AdminRegistration.aspx'</script>");
            }
        }
        catch (Exception)
        {
            Response.Redirect("ErrorPage.aspx");
        }
    }

    protected void btnAdminReset_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("AdminRegistration.aspx");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }
}