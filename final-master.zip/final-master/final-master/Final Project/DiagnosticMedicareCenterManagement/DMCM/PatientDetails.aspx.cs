﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)

        {

            lblPatientId.Text = Session["patientId"].ToString();

            if (lblPatientId.Text != null || lblPatientId.Text != "")

            {

                PatientDaoSqlImpl pt = new PatientDaoSqlImpl();

                Patient patient = pt.DisplaySpecficPatientById(lblPatientId.Text);

                lblPatientFirstName.Text = patient.FirstName;

                lblPatientLastName.Text = patient.LastName;

                lblAge.Text = patient.Age.ToString();

                lblGender.Text = patient.Gender;

                lblDob.Text = patient.DateOfBirth;

                lblPhone.Text = patient.Phone.ToString();

                lblAlternatePhone.Text = patient.AlternatePhone.ToString();

                lblEmail.Text = patient.Email;

                lblAddressLine1.Text = patient.AddressLine1;

                lblAddressLine2.Text = patient.AddressLine2;

                lblCity.Text = patient.City;

                lblState.Text = patient.State;

                lblZipcode.Text = patient.Zipcode.ToString();

            }

        }

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("DoctorPage.aspx");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}