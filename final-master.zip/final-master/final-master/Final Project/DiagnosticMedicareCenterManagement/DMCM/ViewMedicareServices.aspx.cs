﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DisplayMedicareServices();
        }
    }
    protected void DisplayMedicareServices()
    {
        try
        {
            MedicareServiceDaoSqlImpl medicareServiceDao = new MedicareServiceDaoSqlImpl();
            List<MedicareServices> medicareServiceList = medicareServiceDao.GetAllMedicareServices();
            gridMedicareServices.DataSource = medicareServiceList;
            gridMedicareServices.DataBind();
        }
        catch (Exception)
        {
            Response.Redirect("ErrorPage.aspx");
        }

    }
}