﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {

            LoginPanel.Visible = false;
            RegisterPanel.Visible = false;
            
        }
    }

    protected void existingUserRadio_CheckedChanged(object sender, EventArgs e) {
        if (existingUserRadio.Checked == true) {
            RegisterPanel.Visible = false;
            newUserRadio.Checked = false;
            LoginPanel.Visible = true;
           
        }
    }

    protected void newUserRadio_CheckedChanged(object sender, EventArgs e) {
        if (newUserRadio.Checked == true) {
            RegisterPanel.Visible = true;
            existingUserRadio.Checked = false;
            LoginPanel.Visible = false;
            
        }
    }

    protected void DoctorLoginImageButton_Click(object sender, ImageClickEventArgs e) {
        Response.Redirect("DoctorLogin.aspx");
    }

    protected void PatientLoginImageButton_Click(object sender, ImageClickEventArgs e) {
        Response.Redirect("PatientLogin.aspx");
    }

    protected void DoctorRegistrationImageButton_Click(object sender, ImageClickEventArgs e) {
        Response.Redirect("DoctorRegistration.aspx");
    }

    protected void PatientRegistrationImageButton_Click(object sender, ImageClickEventArgs e) {
        Response.Redirect("PatientRegistration.aspx");
    }
}