﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if(!IsPostBack) {
            lblMessage.Visible = false;
        }
    }

    protected void btnDoctorLogin_Click(object sender, EventArgs e) {
        try
        { 
        DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
        int result = doctorDao.DoctorLogin(txtDoctorId.Text, txtDoctorPassword.Text);
        if (result == 1 ) {
            lblMessage.Visible = false;
            lblMessage.Text = "";
            Session["doctorId"] = txtDoctorId.Text;
                Session["doctorName"] = doctorDao.GetDoctorName(txtDoctorId.Text);
                Response.Write("<script>alert('Welcome Doctor');window.location.href='DoctorPage.aspx'</script>");
        }
        if (result == 2) {
            lblMessage.Visible = false;
            Response.Write("<script>alert('Your Status is still Inactive....Try after some time');</script>");
        }
        if (result == 3) {
            lblMessage.Visible = true;
            lblMessage.Text = "Invalid Credentials...Try Again";
            txtDoctorId.Text = "";
            txtDoctorPassword.Text = "";
            txtDoctorId.Focus();
        }
            if (result == 4)
            {
                Response.Write("<script>alert('Unable to login...Your status is rejected');</script>");
            }
        }
        catch (Exception exception) {
            Console.WriteLine(exception.Message);
            Response.Redirect("ErrorPage.aspx");
        }
    }
}