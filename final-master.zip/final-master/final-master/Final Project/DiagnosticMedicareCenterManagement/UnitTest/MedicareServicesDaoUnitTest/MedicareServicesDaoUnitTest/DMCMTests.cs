﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
using System.Collections.Generic;

namespace MedicareServicesDaoUnitTest
{
    [TestClass]
    public class DMCMTests
    {
        [TestMethod]
        public void TestMedicareServicesRegistration()
        {
            MedicareServices medicareService = new MedicareServices();
            MedicareServiceDaoSqlImpl medicareServiceDaoSqlImpl = new MedicareServiceDaoSqlImpl();
            medicareService.MedicareServiceName = "Anesthesiologist";
            medicareService.MedicareDescription = "A physian who are trained to manage patient pain and vital signs during surgery.";
            medicareService.MedicareAmount = 700;
            int result = medicareServiceDaoSqlImpl.AddMedicareService(medicareService);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void TestGetAllMedicareServices()
        {
            MedicareServices medicareService = new MedicareServices();
            MedicareServiceDaoSqlImpl medicareServiceDaoSqlImpl = new MedicareServiceDaoSqlImpl();           
            List<MedicareServices> result = medicareServiceDaoSqlImpl.GetAllMedicareServices();
            Assert.AreEqual(12, result.Count);
        }
    }
}
