﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao
{
    interface IAppointmentDao
    {
        int BookAppointment(string patientId,string doctorId,Appointment appointment);
        int ModifyAppointmentStatus(string reportStatus,string status,string patientId,string doctorId, DateTime date);
        List<Appointment> ViewPatientAppointments(string patientId);
        List<Patient> ViewDoctorAppointments(string doctorId);
        int CheckAppointment(DateTime appointmentDate,string patientId,string doctorId);
    }
}
