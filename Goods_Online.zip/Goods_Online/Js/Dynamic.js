const Products=[
{pname:'Food',expDate:'20/12/2020',cost:'500.00'},
{pname:'Fruit',expDate:'23/11/2019',cost:'400.00'},
{pname:'Vegetable',expDate:'16/09/2019',cost:'500.00'}
];

//Loop through each element of the above collection

products.forEach(function(product)
{
let table=document.querySelector("#tab"); //#tab is the id of the table
//create row for the table
let tr=document.createElement("tr");

//create column for productname
let td1=document.createElement("td");
//fill the td1 with values from product name present in array
td1.textContent=product.pname;

//create column for expirydate
let td2=document.createElement("td");
//fill the td2 with values from expirydate present in array
td2.textContent=product.expDate;

//create column for product cost
let td3=document.createElement("td");
//fill the td3 with values from cost present in array
td3.textContent=product.cost;

//Add the tds to tr
tr.appendChild(td1);
tr.appendChild(td2);
tr.appendChild(td3);

//Add the row to the table
table.appendChild(tr);

});