const products=[
	{pname:'Food',expDate:'20/12/2020',price:'7000.23'},
	{pname:'Beverage',expDate:'18/09/2026',price:'5000.00'},
	{pname:'Clothes',expDate:'22/09/2026',price:'9000.00'},
	{pname:'Utensils',expDate:'11/09/2026',price:'11000.23'}

];
products.forEach(function(product){
	let table=document.querySelector("#tab");
	
//create table row
	let tr=document.createElement("tr");
	
//create columns and add data to column
	let td1=document.createElement("td");
	td1.textContent=product.pname;
	let td2=document.createElement("td");
	td2.textContent=product.expDate;
	let td3=document.createElement("td");
	td3.textContent=product.price;
        
//hyperlink column
	let td4=document.createElement("td");
	let a=document.createElement("a");
	a.textContent="Edit";		
	a.href="EditProduct.html";
	//add this achor tag to td4
	td4.appendChild(a);

	tr.appendChild(td1);
	tr.appendChild(td2);
	tr.appendChild(td3);
	tr.appendChild(td4);

	table.appendChild(tr);
});