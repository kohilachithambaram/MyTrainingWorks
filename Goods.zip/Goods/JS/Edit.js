function validate()
{
//collect info of textboxes under variables
var pname=document.forms["Edit_Form"]["pname_txt"].value;
var expDate=document.forms["Edit_Form"]["expDate_txt"].value;
var price=document.forms["Edit_Form"]["price_txt"].value;

//required check for product name
if(pname==null || pname=="")
{
alert("Product required");
return false;
}

//length of product should be between 2 to 65 characters long
if(pname.length<2 || pname.length>65)
{
alert("Product name wrong");
return false;
}

//required check for expiry date
if(expDate==null || expDate=="")
{
alert("Date required");
return false;
}

var pattern=/^(0[1-9]|[12][0-9]|3[01])[\- \/.](?:(0[1-9]|1[012])[\- \/.](19|20)[0-9]{2})$/;
if(!expDate.match(pattern))
{
alert("Date input wrong");
return false;
}

//required check for cost
if(price==null || price=="")
{
alert("Cost required");
return false;
}

//check for number
if(isNaN(price)) //is not a number
{
alert("Cost wrong..enter numbers");
return false;
}

//ddl not selected validation
var checkSelection=document.getElementById("catagory_ddl");
//extract data via dropdown index position where index starts from 0
var value_info=checkSelection.options[checkSelection.selectedIndex].value;
if(value_info=="Select")
{
alert("No category selected");
return false;
}
}

function check_radio()
{
if(document.getElementById("active_yes").checked==true) //ie user has clicked on yes radio
{
alert("Yes active");
}
if(document.getElementById("active_no").checked==true) //ie user has clicked on yes radio
{
alert("Not Active");
}
}


function check_option()
{
if(document.getElementById("Delivery_chk").checked==true)
{
alert("Free Delivery available");
}
else
{
alert("Free Delivery not available");
}
}
