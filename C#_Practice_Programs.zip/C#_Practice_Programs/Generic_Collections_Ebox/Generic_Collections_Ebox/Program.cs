﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Generic_Collections_Ebox
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("List of currently available 3 Television brands ");
            Console.WriteLine("Videocon");
            Console.WriteLine("Onida ");
            Console.WriteLine("Samsung ");
            List<string> televisions = new List<string>();
            televisions.Add("Videocon");
            televisions.Add("Onida");
            televisions.Add("Samsung");
            Console.WriteLine("Please enter the Television brand to add to the list ");
            string newTelevision = Console.ReadLine();
            televisions.Add(newTelevision);
            int count = televisions.Count;
            Console.WriteLine("List of currently available " + count + " Television brands ");
            foreach(string television in televisions)
            {
                Console.WriteLine(television);
            }*/

            /*Dictionary<int, string> students = new Dictionary<int, string>();
            students.Add(1,"Alok");
            students.Add(2, "Nadeem");
            students.Add(3, "Udit");
            Console.WriteLine("List of stydents in the department");
            foreach(var details in students)
            {
                Console.WriteLine("Id: " + details.Key + ", Name: " + details.Value);
            }*/

            /*List<int> match = new List<int>();
            int size = int.Parse(Console.ReadLine());
            for(int i = 0; i < size ; i++)
            {
                match.Add(int.Parse(Console.ReadLine()));
            }

            Console.WriteLine(match.Sum());
            Console.WriteLine(match.Average());*/

            /*List<int> runs = new List<int>();
            int size = int.Parse(Console.ReadLine());
            
            for (int i = 0; i < size; i++)
            {
                runs.Add(int.Parse(Console.ReadLine()));
            }

            runs.Sort();
            foreach (int run in runs)
            {
                Console.WriteLine(run);
            }*/

            
        }
    }
}
