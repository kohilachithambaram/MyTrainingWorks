﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Example
{
    class TraineeBO
    {
        public static void Display(Trainee trainee)
        {
            Console.WriteLine(trainee);
        }
    }
}
