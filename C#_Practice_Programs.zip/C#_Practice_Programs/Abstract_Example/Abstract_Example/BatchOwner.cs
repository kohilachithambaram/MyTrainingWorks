﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Example
{
    interface BatchOwner
    {
        //for interface do not use any access specifier
        int attendanceTracker(int dutyHours);
    }
}
