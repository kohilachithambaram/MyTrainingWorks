﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Example
{
    abstract class Batch
    {
        private string _batchCode;
        private string _location;

        public Batch()
        {
                
        }
        public Batch(string _batchCode, string _location)
        {
            this._batchCode = _batchCode;
            this._location = _location;
        }

        public string BatchCode
        {
            get
            {
                return _batchCode;
            }

            set
            {
                _batchCode = value;
            }
        }

        public string Location
        {
            get
            {
                return _location;
            }

            set
            {
                _location = value;
            }
        }

        public abstract double Result(float marks1, float marks2);
        
    }
}
