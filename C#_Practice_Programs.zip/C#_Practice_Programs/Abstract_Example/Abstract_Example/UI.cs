﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Example
{
    class UI
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the batch details separated by comas");
            string[] batchInfo = Console.ReadLine().Split(',');
            Console.WriteLine("Enter the trainee name , marks1 and marks2 using comas");
            string[] traineeInfo = Console.ReadLine().Split(',');

            Trainee tr = new Trainee(batchInfo[0] , batchInfo[1] , traineeInfo[0] , float.Parse(traineeInfo[1]) , float.Parse(traineeInfo[2]));

            Console.WriteLine("\nDisplay trainee details");

            TraineeBO.Display(tr);

            Console.WriteLine("Marks: " + tr.Result(float.Parse(traineeInfo[1]), float.Parse(traineeInfo[2])));

            Console.WriteLine("Enter the hours worked");
            int TraineeDutyHours = tr.attendanceTracker(int.Parse(Console.ReadLine()));

            if(TraineeDutyHours < 400)
            {
                Console.WriteLine("Top Up required = " + (400 - TraineeDutyHours));
            }
            else
            {
                Console.WriteLine("Total hours completed : " + TraineeDutyHours);
            }

            Console.WriteLine("Enter the Passport number (NA if not present)");

            string passport = Console.ReadLine();

            bool checker = tr.hrPolicy(passport);

            if(checker == true)
            {
                Console.WriteLine("Passport Submitted");
            }
            else
            {
                Console.WriteLine("Passport submission is pending with Hr");
            }
        }
    }
}
