﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Example
{
    class Trainee:Batch,BatchOwner,HR
    {
        private string _name;
        private float _marks1;
        private float marks2;

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public float Marks1
        {
            get
            {
                return _marks1;
            }

            set
            {
                _marks1 = value;
            }
        }

        public float Marks2
        {
            get
            {
                return marks2;
            }

            set
            {
                marks2 = value;
            }
        }

        public Trainee()
        {

        }

        public Trainee(string _batchCode, string _location,string _name, float _marks1, float marks2):
            base(_batchCode,_location)
        {
            this._name = _name;
            this._marks1 = _marks1;
            this.marks2 = marks2;
        }

        //override the base class abstract method
        public override double Result(float marks1, float marks2)
        {
            double averageMarks = (marks1 + marks2) / 2;
            return averageMarks;
        }

        public override string ToString()
        {
            return string.Format("Batch Code: {0}\nLocation: {1}\nTrainee Name: {2}", base.BatchCode, base.Location, this._name);
        }

        public int attendanceTracker(int dutyHours)
        {
            return 5 * dutyHours;
        }

        public bool hrPolicy(string passportNumber)
        {
            if (passportNumber != "NA")
                return true;
            else
                return false;
        }
    }
}
