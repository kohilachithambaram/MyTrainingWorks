﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_Enum_and_FileHandling
{
    //override enum values
    enum LineOfBusiness
    {
        BFS,
        Healthcare,
        Insurance
    }

    class Program
    {
        static void Main(string[] args)
        {
            /* Console.WriteLine("Print value present under east: "
               + (int)direction.east);
             Console.WriteLine("Print value present under south: "
               + (int)direction.south);*/
            //create a filestream for writing purpose
            FileStream fs = new FileStream(@"D:/EnumExample.txt",
            FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter writter = new StreamWriter(fs);

            //Print names of placeholder present under enum
            foreach (string d in Enum.GetNames(typeof(LineOfBusiness)))
            {
                writter.WriteLine(d);
                writter.Flush();
            }
            Console.WriteLine("File Writing completed");
            writter.Close();
            fs.Close();
        
            //create a filestream for reading purpose
            FileStream fs1 = new FileStream(@"D:/EnumExample.txt",
           FileMode.OpenOrCreate, FileAccess.Read);
            StreamReader reader = new StreamReader(fs1);
            reader.BaseStream.Seek(0, SeekOrigin.Begin);
            string storage = string.Empty;
            while ((storage = reader.ReadLine()) != null)
            //read data till EOF
            {
                Console.WriteLine(storage);
            }
            Console.WriteLine("\nData Reading completed");
            reader.Close();
            fs1.Close();
        }
    }
}
