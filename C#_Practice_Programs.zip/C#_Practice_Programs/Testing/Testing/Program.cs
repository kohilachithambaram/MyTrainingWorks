﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[,] a = { { 5, 4, 3 }, { 9, 2, 6 } };
            //Console.WriteLine(a.Length);
            // int[] arr;
            //for(int i = 0; i < )
            //Console.WriteLine(arr.Length);
            int iData = 0;
        }
    }
}
