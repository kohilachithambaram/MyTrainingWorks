﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_Polymorphism_Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Menu\n1.Player details of the delivery\n2.Run details of the delivery");
            int choice = int.Parse(Console.ReadLine());

            Delivery delivery = new Delivery();

            if (choice == 1)
            {
                Console.WriteLine("Enter the bowler name");
                string bowler = Console.ReadLine();
                Console.WriteLine("Enter the batsman name");
                string batsman = Console.ReadLine();
                delivery.DisplayDeliveryDetails(bowler,batsman);
            }
            else if (choice == 2)
            {
                Console.WriteLine("Enter the number of runs");
                long runs = long.Parse(Console.ReadLine());
                delivery.DisplayDeliveryDetails(runs);
            }
        }
    }
}
