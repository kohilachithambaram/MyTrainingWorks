﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_Polymorphism_Interface
{
    class Delivery
    {
        
        public void DisplayDeliveryDetails(string bowler , string batsman)
        {
            Console.WriteLine("Player details of the delivery");
            string[] bowlerName = bowler.Split(' ');
            Console.WriteLine("Bowler - " + bowlerName[bowlerName.Length - 1]);
            string[] batsmanName = batsman.Split(' ');
            Console.WriteLine("Batsman - " + batsmanName[batsmanName.Length -1]);
        }

        public void DisplayDeliveryDetails(long runs)
        {
            if(runs == 4)
            {
                Console.WriteLine("Number of runs scored in the delivery : 4 \nIt is a boundary.");
            }
            else if (runs == 6)
            {
                Console.WriteLine("Number of runs scored in the delivery : 6 \nIt is a six.");
            }
            else
            {
                Console.WriteLine("Number of runs scored in the delivery : " + runs);
            }
        }
    }
}
