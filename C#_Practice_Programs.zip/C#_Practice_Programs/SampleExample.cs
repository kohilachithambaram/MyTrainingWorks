//Namespace
using System;
class SampleExample
{
	static void Main()
	{
		Console.WriteLine("Welcome to C#");
	}
}