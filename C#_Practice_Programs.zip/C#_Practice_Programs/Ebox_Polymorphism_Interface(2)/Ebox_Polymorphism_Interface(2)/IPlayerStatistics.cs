﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_Polymorphism_Interface_2_
{
    interface IPlayerStatistics
    {
        void DiplayPlayerStatistics();
    }
}
