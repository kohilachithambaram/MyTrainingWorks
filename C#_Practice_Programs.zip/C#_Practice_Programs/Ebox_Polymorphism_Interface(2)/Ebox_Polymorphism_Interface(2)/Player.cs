﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_Polymorphism_Interface_2_
{
    abstract class Player
    {
        private string _name;
        private string _teamName;
        private int _noOfMatches;

        protected string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        protected string TeamName
        {
            get
            {
                return _teamName;
            }

            set
            {
                _teamName = value;
            }
        }

        protected int NoOfMatches
        {
            get
            {
                return _noOfMatches;
            }

            set
            {
                _noOfMatches = value;
            }
        }

        public Player(string _name, string _teamName, int _noOfMatches)
        {
            this.Name = _name;
            this.TeamName = _teamName;
            this.NoOfMatches = _noOfMatches;
        }
    }
}
