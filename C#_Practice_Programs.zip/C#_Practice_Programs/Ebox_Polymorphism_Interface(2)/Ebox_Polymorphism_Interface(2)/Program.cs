﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_Polymorphism_Interface_2_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Menu\n1.Cricket Player Details\n2.Hockey Player Details\nEnter Choice");
            int choice = int.Parse(Console.ReadLine());
            if(choice == 1)
            {
                Console.WriteLine("Enter player name");
                string playerName = Console.ReadLine();
                Console.WriteLine("Enter team name");
                string teamName = Console.ReadLine();
                Console.WriteLine("Enter number of matches played");
                int matchesPlayed = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter total runs scored");
                int runsScored = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter number of wickets taken");
                int wicketsTaken = int.Parse(Console.ReadLine());

                CricketPlayer cricketPlayer = new CricketPlayer(playerName,teamName,matchesPlayed,runsScored,wicketsTaken);

                cricketPlayer.DiplayPlayerStatistics();
            }

            else if (choice == 2)
            {
                Console.WriteLine("Enter player name");
                string playerName = Console.ReadLine();
                Console.WriteLine("Enter team name");
                string teamName = Console.ReadLine();
                Console.WriteLine("Enter number of matches played");
                int matchesPlayed = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the position");
                string position = Console.ReadLine();
                Console.WriteLine("Enter total number of goals taken");
                int goalsTaken = int.Parse(Console.ReadLine());

                HockeyPlayer cricketPlayer = new HockeyPlayer(playerName, teamName, matchesPlayed, position, goalsTaken);

                cricketPlayer.DiplayPlayerStatistics();
            }
        }
    }
}
