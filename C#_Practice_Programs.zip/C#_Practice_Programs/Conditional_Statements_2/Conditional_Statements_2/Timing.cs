﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conditional_Statements_2
{
    class Timing
    {
        static void Main(string[] args)
        {
            string timing = Console.ReadLine();
            if(timing.Equals("Morning",StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Friends");
            }

            else if (timing.Equals("Afternoon", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Girlfriend");
            }

            else if (timing.Equals("Evening", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Practice");
            }

            else if (timing.Equals("Night", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Biking");
            }
        }
    }
}
