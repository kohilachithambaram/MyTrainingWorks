﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositionExample
{
    class EmployeePL
    {
        static void Main()
        {
            Console.WriteLine("Enter the emp name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter employee skill set");
            string skill = Console.ReadLine();
            Console.WriteLine("Enter the experience (in years)");
            int noOfYears = int.Parse(Console.ReadLine());

            //Pass data to experience
            Experience exp = new Experience(skill,noOfYears);

            //Pass data to employee
            Employee emp = new Employee(name,exp);

            //call the  BO for output
            Console.WriteLine("Employee Details");
            EmployeeBO.Display(emp);
        }
    }
}
