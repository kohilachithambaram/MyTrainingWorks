﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositionExample
{
    class Experience
    {
        private string _skill;
        private int _noOfYears;

        public Experience()
        {

        }
        public Experience(string _skill, int _noOfYears)
        {
            this._skill = _skill;
            this._noOfYears = _noOfYears;
        }

        public string Skill
        {
            get
            {
                return _skill;
            }

            set
            {
                _skill = value;
            }
        }

        public int NoOfYears
        {
            get
            {
                return _noOfYears;
            }

            set
            {
                _noOfYears = value;
            }
        }
        public override string ToString()
        {
            return string.Format("Skill : {0}\nYears of Experience : {1}" ,this._skill,this._noOfYears);
        }
    }
}
