﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositionExample
{
    class Employee
    {
        private string _name;
        private Experience _experience;

        public Employee(string _name, Experience _experience)
        {
            this._name = _name;
            this._experience = _experience;
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        internal Experience Experience
        {
            get
            {
                return _experience;
            }

            set
            {
                _experience = value;
            }
        }

        public Employee()
        {

        }

        public override string ToString()
        {
            return string.Format("Name : {0} \nExperience Info :\n{1}",this._name,this._experience);
        }
    }
}
