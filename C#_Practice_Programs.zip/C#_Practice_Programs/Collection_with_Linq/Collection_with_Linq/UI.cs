﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Business Rule : id should be number and 4 digits in length
//Regex for this work 
using System.Text.RegularExpressions;

namespace Collection_with_Linq
{
    class UI
    {
        static void Main(string[] args)
        {
            /*
            //int id = int.Parse(data[1]);*/
            List<Employee> empList = new List<Employee>();
            Employee emp = new Employee();
            string cont = ""; // or cont = string.Empty
            int menu = 0;

            label_dataentry:
            try
            {
                do
                {
                    Console.WriteLine("Enter the name and id");
                    string[] data = Console.ReadLine().Split(',');
                    if (Regex.IsMatch(data[1], "^[0-9]{4}$"))
                    {
                        //put data under employee constructor and pass the employee constructor under Add() of List
                        empList.Add(new Employee(data[0] , int.Parse(data[1])));
                    }
                    else
                    {
                        throw new EmployeeBO("Id is incorrect");
                    }
                    Console.WriteLine("Enter another employee?(yes/no)");
                    cont = Console.ReadLine();
                }
                while (cont.Equals("yes",StringComparison.InvariantCultureIgnoreCase));
            }
            catch(EmployeeBO ebo)
            {
                Console.WriteLine("Exception : " + ebo);
                Console.WriteLine("Enter the details again");
                goto label_dataentry;
            }

            Console.WriteLine();
            //Display the data
            do
            {
                Console.WriteLine("Menu\n1.All Employee\n2.Filtered by ID\n3.Exit");
                menu = int.Parse(Console.ReadLine());
                switch(menu)
                {
                    case 1:
                        EmployeeBO.Display(empList);
                        break;
                    case 2:
                        Console.WriteLine("Enter id to search : ");
                        int search = int.Parse(Console.ReadLine());
                        Employee empp = EmployeeBO.Display(empList,search);
                        if (empp != null)
                            Console.WriteLine(empp);
                        else
                            Console.WriteLine("No record found");
                        break;
                    case 3:
                        //terminate C# program
                        Environment.Exit(0);
                        break;
                }
            }
            while (menu != 3);
        }
    }
}
