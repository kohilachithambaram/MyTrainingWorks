﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection_with_Linq
{
    class Employee
    {
        private string _name;
        private int _id;

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public Employee()
        {

        }

        public Employee(string _name, int _id)
        {
            this._name = _name;
            this._id = _id;
        }
        public override string ToString()
        {
            return string.Format("{0,-20}{1}" , this._id, this._name);
        }
    }
}
