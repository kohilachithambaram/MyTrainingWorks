﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conditional_Statements
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            if (n > 0)
            {

                string[] teams = new string[n];
                for (int i = 0; i < n; i++)
                {
                    teams[i] = Console.ReadLine();
                }
                string toSearch = Console.ReadLine();
                int flag = 0;
                if (teams.Contains(toSearch))
                {
                    flag = 1;
                }
                else
                {
                    flag = 0;
                }
                if (flag == 1)
                {
                    Console.WriteLine("Yes" + Array.IndexOf(teams, toSearch) + 1);
                }
                else
                {
                    Console.WriteLine("No");
                }
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
