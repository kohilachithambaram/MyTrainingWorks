﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Election
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Current constituency vote count details in ‘Constituency number – vote count’ format: ");
            int[] votes = new int[3];
            for(int i = 0; i < 3; i++)
            {
                Console.Write(i + 1 + " - ");
                votes[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Please provide the constituency number for which the vote count should be modified: ");
            int index = int.Parse(Console.ReadLine());

            Console.WriteLine("Please provide the new vote count: ");
            int newVote = int.Parse(Console.ReadLine());

            for(int i = 0; i < 3; i++)
            {
                if(i == index - 1)
                {
                    votes[i] = newVote;
                }
            }

            Console.WriteLine("Current constituency vote count details in ‘Constituency number – vote count’ format: ");
            for(int i = 0; i < 3; i++)
            {
                Console.WriteLine(i + 1 + " - " + votes[i]);
            }
        }
    }
}
