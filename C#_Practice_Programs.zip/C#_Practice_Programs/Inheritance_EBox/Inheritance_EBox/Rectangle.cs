﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_EBox
{
    class Rectangle:Shape
    {
        private int _length;
        private int _breadth;

        public int Length
        {
            get
            {
                return _length;
            }

            set
            {
                _length = value;
            }
        }

        public int Breadth
        {
            get
            {
                return _breadth;
            }

            set
            {
                _breadth = value;
            }
        }

        public Rectangle()
        {

        }

        public Rectangle(string _name ,int _length, int _breadth):base(_name)
        {
            this._length = _length;
            this._breadth = _breadth;
        }

        public override float CalculateArea()
        {
            return this._length * this._breadth;
        }
    }
}
