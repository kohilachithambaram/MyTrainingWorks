﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_EBox
{
    class Square:Shape
    {
        private int _side;

        public Square()
        {

        }

        public Square(string _name , int _side):base(_name)
        {
            this._side = _side;
        }

        public int Side
        {
            get
            {
                return _side;
            }

            set
            {
                _side = value;
            }
        }

        public override float CalculateArea()
        {
            return this._side * this._side;
        }
    }
}
