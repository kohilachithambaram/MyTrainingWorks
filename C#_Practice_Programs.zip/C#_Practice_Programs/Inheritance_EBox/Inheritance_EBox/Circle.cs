﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_EBox
{
    class Circle:Shape
    {
        private int _radius;

        public int Radius
        {
            get
            {
                return _radius;
            }

            set
            {
                _radius = value;
            }
        }

        public Circle()
        {

        }

        public Circle(string _name,int _radius):base(_name)
        {
            this._radius = _radius;
        }

        public override float CalculateArea()
        {
            return 3.14F * this._radius * this._radius;
        }
    }
}
