﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_EBox
{
    abstract class Shape
    {
        private string _name;

        public Shape()
        {

        }

        public Shape(string _name)
        {
            this._name = _name;
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        /* Example for declaring virtual method without declaring the class as abstract and overridding it in other classes
        public virtual float CalculateArea()
        {
            return 0;
        }*/

        public abstract float CalculateArea();
    }
}
