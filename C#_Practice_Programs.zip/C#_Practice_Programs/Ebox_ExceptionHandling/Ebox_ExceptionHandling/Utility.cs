﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_ExceptionHandling
{
    class Utility:Exception
    {
        private string _msg;

        public Utility()
        {

        }

        public Utility(string _msg)
        {
            this.Msg = _msg;
        }

        public string Msg
        {
            get
            {
                return _msg;
            }

            set
            {
                _msg = value;
            }
        }

        public static string GetLOBAcctCount(string name , int count)
        {
            return string.Format("The LOB {0} has {1} accounts", name, count);
        }

        public override string ToString()
        {
            return string.Format("{0}",this._msg);
        }
    }
}
