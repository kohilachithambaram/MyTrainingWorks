﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        { 
            try
            {
                Console.WriteLine("Please enter the Line Of Business(LOB) name");
                string name = Console.ReadLine();
                Console.WriteLine("Please enter the account count for the LOB");
                //int count = int.Parse(Console.ReadLine());
                //Console.WriteLine("The LOB {0} has {1} accounts",name,count);
                char[] countArray = Console.ReadLine().ToCharArray();
                int n = 0;
                foreach(char ch in countArray)
                {
                    if(char.IsDigit(ch))
                    {
                        n++;
                    }
                }
                int digit = 0;
                if(n == countArray.Length)
                {
                    digit = int.Parse(new string(countArray));
                    Console.WriteLine(Utility.GetLOBAcctCount(name, digit));
                }
                else
                {
                    throw new Utility("Incorrect value provided for Account count. Please check." ) ;
                }
                
                
            }
           /* catch(FormatException fe)
            {
                Console.WriteLine("Incorrect value provided for Account count. Please check. ");
            }*/
            catch(Utility e)
            {
                //Console.WriteLine(e.Message);
                Console.WriteLine("Exception caught at Main method: " + e);
            }
        }
    }
}
