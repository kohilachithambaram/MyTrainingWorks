﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variables_and_Operators_2
{
    class Program
    {
        static void Main(string[] args)
        {
            float fahrenheit = float.Parse(Console.ReadLine());
            float Centigrade = (fahrenheit - 32) * 5 / 9;
            Console.WriteLine(Centigrade.ToString("0.00"));
            float flData = 4 % 2;
            Console.WriteLine(flData);
        }
    }
}
