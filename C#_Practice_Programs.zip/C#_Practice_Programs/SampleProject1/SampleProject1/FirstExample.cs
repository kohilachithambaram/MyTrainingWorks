﻿using System;

namespace SampleProject1
{
    class FirstExample
    {
        static void Main(string[] args)
        {
            //ctrl+f5 to compile the program
            Console.WriteLine("Welcome to C#");
            int id = 1001;
            float fee = 1000.234F;
            double salary = 32000;
            string name = "koki";
            char gender = 'F';
            DateTime dt;

            Console.WriteLine("Old Syntax");
            Console.WriteLine("Id: " + id + "\nName: " + name);
            Console.WriteLine("New Syntax");
            Console.WriteLine("Id: {0}\nName: {1}",id,name);
            Console.WriteLine("Id: {0}\nName: {1}\nGender{2}: "+
                "\nFees: {3}\nSalary: {4}",id,name,gender,fee,salary);
        }
    }
}
