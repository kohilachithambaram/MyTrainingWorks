﻿using System;

namespace InheritanceExample
{
    class Product
    {
        private string _prodNo;
        private string _brandName;
        private string _prodType;
        private double _prodCost;

        public string ProdNo
        {
            get
            {
                return _prodNo;
            }

            set
            {
                _prodNo = value;
            }
        }

        public string BrandName
        {
            get
            {
                return _brandName;
            }

            set
            {
                _brandName = value;
            }
        }

        public string ProdType
        {
            get
            {
                return _prodType;
            }

            set
            {
                _prodType = value;
            }
        }

        public double ProdCost
        {
            get
            {
                return _prodCost;
            }

            set
            {
                _prodCost = value;
            }
        }

        public Product()
        {

        }

        public Product(string _prodNo, string _brandName, string _prodType, double _prodCost)
        {
            this.ProdNo = _prodNo;
            this.BrandName = _brandName;
            this.ProdType = _prodType;
            this.ProdCost = _prodCost;
        }
        public virtual double BillingAmount()
        {
            return 0;
        }
    }
}
