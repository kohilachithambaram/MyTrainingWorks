﻿using System;

namespace InheritanceExample
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Random Class : This class contains method called Next() to generate numbers randomly.
             Next(starting_number,ending_number)*/

            Random rd = new Random();
            int invoiceNo = rd.Next(1001,9999);
            Console.WriteLine("Enter the product no");
            string prodNo = Console.ReadLine();
            Console.WriteLine("Enter type");
            string type = Console.ReadLine();
            Console.WriteLine("Enter Brand");
            string brand = Console.ReadLine();
            Console.WriteLine("Enter the baseprice");
            double price = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the cust name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the Quantity");
            int quantity = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the date of order");
            DateTime dt = DateTime.ParseExact(Console.ReadLine(),"dd/MM/yyyy",null);

            //Pass data under constructor foe sales
            Sales sales = new Sales(invoiceNo,name,quantity,dt,prodNo,brand,type,price);

            Console.WriteLine("\n********Invoice Bill********");
            Console.WriteLine(sales);
            Console.WriteLine("Total Bill : " + sales.BillingAmount());
        }
    }
}
