﻿using System;


namespace InheritanceExample
{
    class Sales:Product
    {
        private int _invoiceNo;
        private string _customerName;
        private int _quantity;
        private DateTime _orderDate;

        public int InvoiceNo
        {
            get
            {
                return _invoiceNo;
            }

            set
            {
                _invoiceNo = value;
            }
        }

        public string CustomerName
        {
            get
            {
                return _customerName;
            }

            set
            {
                _customerName = value;
            }
        }

        public int Quantity
        {
            get
            {
                return _quantity;
            }

            set
            {
                _quantity = value;
            }
        }

        public DateTime OrderDate
        {
            get
            {
                return _orderDate;
            }

            set
            {
                _orderDate = value;
            }
        }

        public Sales()
        {

        }

        public Sales(int _invoiceNo, string _customerName, int _quantity, DateTime _orderDate, string _prodNo, string _brandName, string _prodType, double _prodCost):
            base(_prodNo, _brandName, _prodType, _prodCost)
        {
            this._invoiceNo = _invoiceNo;
            this._customerName = _customerName;
            this._quantity = _quantity;
            this._orderDate = _orderDate;
        }

        public override string ToString()
        {
            return string.Format("Ivoice No : {0}\nProduct No : {1}\nType : {2}\nBrand : {3}\nCustomer Name : {4}\nBase Cost : {5}\nQuantity : {6}",
                this._invoiceNo,base.ProdNo,base.ProdType,base.BrandName,this._customerName,base.ProdCost,this._quantity);
        }

        public override double BillingAmount()
        {
            return (base.ProdCost * this._quantity) - ((base.ProdCost * 5.25) / 100);
        }
    }
}
