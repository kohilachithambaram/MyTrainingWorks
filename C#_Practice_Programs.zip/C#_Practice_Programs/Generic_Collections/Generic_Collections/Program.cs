﻿using System;
using System.Collections.Generic;

namespace Generic_Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> states = new List<string>();

            HashSet<string> cities = new HashSet<string>();

            SortedSet<int> pincodes = new SortedSet<int>();

            Dictionary<int,string>  companies = new Dictionary<int,string>();

            SortedDictionary<int,string>  deoartments = new SortedDictionary<int,string>();

            
        }
    }
}
