﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_ExceptionHandling_3
{
    class CustomExceptions:Exception
    {
        private string _msg;

        public CustomExceptions()
        {

        }

        public CustomExceptions(string _msg)
        {
            this.Msg = _msg;
        }

        public string Msg
        {
            get
            {
                return _msg;
            }

            set
            {
                _msg = value;
            }
        }

        public static string Addition(int firstNumber , int secondNumber)
        {
            return string.Format("Addition of two numbers is {0}" , (firstNumber + secondNumber));
        }

        public override string ToString()
        {
            return string.Format("{0}", this._msg);
        }
    }
}
