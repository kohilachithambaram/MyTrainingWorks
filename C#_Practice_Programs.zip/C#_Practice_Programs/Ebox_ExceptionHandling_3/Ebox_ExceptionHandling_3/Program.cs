﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_ExceptionHandling_3
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Please enter the first number");
                string _firstNumber = Console.ReadLine();
                Console.WriteLine("Please enter the second number");
                string _secondNumber = Console.ReadLine();

                if (_firstNumber == null || _firstNumber == "" || _secondNumber == null || _secondNumber == "")
                {
                    throw new CustomExceptions("Please provide valid Input");
                }
                else
                {
                    int firstNumber = int.Parse(_firstNumber);
                    int secondNumber = int.Parse(_secondNumber);
                    Console.WriteLine(CustomExceptions.Addition(firstNumber, secondNumber));
                }
            }
            catch(CustomExceptions customException)
            {
                Console.WriteLine(customException);
            }
        }
    }
}
