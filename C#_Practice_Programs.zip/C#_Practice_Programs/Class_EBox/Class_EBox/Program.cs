﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_EBox
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the player name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the country name");
            string country = Console.ReadLine();
            Console.WriteLine("Enter the skill");
            string skill = Console.ReadLine();

            PlayerDAO playerDetails = new PlayerDAO();

            playerDetails.Name = name;
            playerDetails.Country = country;
            playerDetails.Skill = skill;

            Console.WriteLine("\nPlayer Details");
            Console.WriteLine("Player Name : " + playerDetails.Name);
            Console.WriteLine("Country Name : " + playerDetails.Country);
            Console.WriteLine("Skill : " + playerDetails.Skill);
        }
    }
}
