﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_EBox
{
    class PlayerDAO
    {
        private string _name;
        private string _country;
        private string _skill;

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public string Country
        {
            get
            {
                return _country;
            }

            set
            {
                _country = value;
            }
        }

        public string Skill
        {
            get
            {
                return _skill;
            }

            set
            {
                _skill = value;
            }
        }

        //type ctor and double time press tab 
        public PlayerDAO()
        {
                
        }

        //create this using selecting all the fields and right click and selecting contructor with fields
        public PlayerDAO(string _name, string _country, string _skill)
        {
            this._name = _name;
            this._country = _country;
            this._skill = _skill;
        }
    }
}
