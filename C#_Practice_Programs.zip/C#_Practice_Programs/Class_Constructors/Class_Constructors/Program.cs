﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Constructors
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the over");
            int over = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the ball");
            int ball = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the runs");
            int runs = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the batsman name");
            string batsman = Console.ReadLine();
            Console.WriteLine("Enter the bowler name");
            string bowler = Console.ReadLine();
            Console.WriteLine("Enter the nonStriker name");
            string nonStriker = Console.ReadLine();

            DeliveryDAO delivery = new DeliveryDAO(over, ball, runs, batsman, bowler, nonStriker);

            Console.WriteLine(delivery);
        }
    }
}
