﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallByReference
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please provide the limit until which the Arithmetic progression series has to be printed ");
            int value = int.Parse(Console.ReadLine());
            while (value > 20)
            {
                Console.WriteLine("Please provide the maximum value less than 20 ");
                value = int.Parse(Console.ReadLine());
            }
            ArithmeticProgression(ref value);
         }

        public static void ArithmeticProgression(ref int value)
        {
            int arithValue = 1;
            while(arithValue <= value)
            { 
                Console.WriteLine(arithValue);
                arithValue += 2;
            }
        }
    }
}
