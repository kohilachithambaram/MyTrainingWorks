﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strings
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("Enter the player name");
            string playerName = Console.ReadLine();
            Console.WriteLine("Enter the starting index");
            int index = int.Parse(Console.ReadLine());
            string shortName = playerName.Substring(index);
            Console.WriteLine("Short name of " + playerName + " : " + shortName);*/

            /*Console.WriteLine("Enter the team name");
            string teamName = Console.ReadLine();
            Console.WriteLine("Enter the starting index of the sequence");
            int startIndex = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the ending index of the sequence");
            int endIndex = int.Parse(Console.ReadLine());
            string shortName = teamName.Substring(startIndex,endIndex);
            Console.WriteLine("Short name of " + teamName + " : " + shortName);*/

            Console.WriteLine("Enter the venue1");
            string venue1 = Console.ReadLine();
            Console.WriteLine("Enter the venue2");
            string venue2 = Console.ReadLine();
            if(venue1.Equals(venue2,StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Both the venues are same.");
            }
            else
            {
                Console.WriteLine("Both the venues are different.");
            }
        }
    }
}
