﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ternary_Checker
{
    class TernaryOperator
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a num");
            int num = int.Parse(Console.ReadLine());
            //Even Odd
            Console.WriteLine("Num is :" + ((num % 2 == 0)?"even" : "Odd"));
        }
    }
}
