﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Handling
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 0;
            int c = 0;
            try
            {
                a = int.Parse(Console.ReadLine());
                if (a < 0)
                    throw new NegativeDataException("Data is Negative");
                b = int.Parse(Console.ReadLine());
                if (a < 0)
                    throw new NegativeDataException("Data is Negative");
                c = a / b;
                Console.WriteLine(c);
            }
            catch(DivideByZeroException de)
            {
                Console.WriteLine(de.Message);
                Console.WriteLine("Exception type : " + de.GetType().Name);
                Console.WriteLine("Donot divide by 0");//Our own message
            }
            catch(FormatException fe)
            {
                Console.WriteLine(fe.Message);
            }
            catch(NegativeDataException ne)
            {
                Console.WriteLine(ne);
                Environment.Exit(0);
            }
            finally
            {
                Console.WriteLine("Finally Block");
            }
        }
    }
}
