﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Exception class for Application Exception if number is -ve
namespace Exception_Handling
{
    class NegativeDataException:Exception
    {
        private string _msg;

        public NegativeDataException()
        {

        }
        public NegativeDataException(string _msg)
        {
            this._msg = _msg;
        }

        public string Msg
        {
            get
            {
                return _msg;
            }

            set
            {
                _msg = value;
            }
        }

        public override string ToString()
        {
            return string.Format("Exception : " + this._msg) ;
        }
    }
}
