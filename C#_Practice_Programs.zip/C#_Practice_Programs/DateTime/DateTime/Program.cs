﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datetime
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your date of joining in ‘mm/dd/yyyy’ format in your current organization.");
            DateTime doj = DateTime.ParseExact(Console.ReadLine(),"MM/dd/yyyy",null);
            DateTime current = DateTime.Now;

            TimeSpan ts = current.Subtract(doj);
            int days = (int)ts.TotalDays;

            Console.WriteLine("It has been " + days + " days since you joined the current organization. ");
        }
    }
}
