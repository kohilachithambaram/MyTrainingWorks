﻿using System;


namespace Variable_Example
{
    class Example_Variable
    {
        //variable data storage
        //datatype variable_name=Console.ReadLine();
        //For non string data use Parse() for type casting
        static void Main(string[] args)
        {
            Console.WriteLine("Enter id:");
            int id = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Fees:");
            float fee = float.Parse(Console.ReadLine());

            Console.WriteLine("Id: {0}\nName: {1}\nFee: {2}",
                id,name,fee);
        }
    }
}
