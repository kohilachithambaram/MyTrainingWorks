﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
    class EmployeeDAO
    {
        private int _empId;
        private string _empName;
        private double _empSalary;

        public int EmpId
        {
            get
            {
                return _empId;
            }

            set
            {
                _empId = value;
            }
        }

        public string EmpName
        {
            get
            {
                return _empName;
            }

            set
            {
                _empName = value;
            }
        }

        public double EmpSalary
        {
            get
            {
                return _empSalary;
            }

            set
            {
                _empSalary = value;
            }
        }

        public EmployeeDAO()
        {

        }

        public EmployeeDAO(int _empId, string _empName, double _empSalary)
        {
            this._empId = _empId;
            this._empName = _empName;
            this._empSalary = _empSalary;
        }

        public override string ToString()
        {
            return string.Format("ID:{0}\nName:{1}\nSalary:{2}",this._empId,this._empName,this._empSalary);
        }
    }
}
