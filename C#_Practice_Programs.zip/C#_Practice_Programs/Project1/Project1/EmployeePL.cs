﻿using System;

namespace Project1
{
    //PL
    class EmployeePL
    {
        static void Main(string[] args)
        {
            //To use the property we need class object
            //EmployeeDAO dao = new EmployeeDAO();

            //Enter data from console
            Console.WriteLine("Enter the data");
            string[] data = Console.ReadLine().Split(',');

            //create obj including constructor
            EmployeeDAO dao = new EmployeeDAO(int.Parse(data[0]), data[1], double.Parse(data[2]));

            /* //setter
             dao.EmpId = int.Parse(data[0]);
             dao.EmpName = data[1];
             dao.EmpSalary = double.Parse(data[2]);*/

            /*//getter
            Console.WriteLine("\nId : " + dao.EmpId);
            Console.WriteLine("Name : " + dao.EmpName);
            Console.WriteLine("Salary : " + dao.EmpSalary);*/

            Console.WriteLine(dao);
        }
    }
}
