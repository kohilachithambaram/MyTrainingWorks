﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_Linq_features
{
    class Player
    {
        private string _name;
        private int _runs;

        public Player()
        {

        }

        public Player(string _name, int _runs)
        {
            this.Name = _name;
            this.Runs = _runs;
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public int Runs
        {
            get
            {
                return _runs;
            }

            set
            {
                _runs = value;
            }
        }

        public override string ToString()
        {
            return string.Format("{0} {1}",this._name,this._runs);
        }
    }
}
