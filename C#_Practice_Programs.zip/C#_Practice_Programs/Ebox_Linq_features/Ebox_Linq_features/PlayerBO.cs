﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_Linq_features
{
    class PlayerBO
    {
        public static List<Player> Display(List<Player> playerList)
        {
            List<Player> playerLists = new List<Player>();

            var checkData = from d in playerList
                            where d.Runs > 50
                            select d;
            if(checkData.Count() > 0)
            {
                foreach(Player player1 in checkData)
                {
                    playerLists.Add(player1);
                }
            }
            return playerLists;
        }
    }
}
