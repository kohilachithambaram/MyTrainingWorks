﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebox_Linq_features
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Player> playerList = new List<Player>();
            Player player = new Player();
            Console.WriteLine("Enter the number of players");
            int noOfPlayers = int.Parse(Console.ReadLine());
            for(int i = 0; i < noOfPlayers; i++)
            {
                Console.WriteLine("Enter the Player name");
                string _name = Console.ReadLine();
                Console.WriteLine("Enter score");
                int _score = int.Parse(Console.ReadLine());

                playerList.Add(new Player(_name,_score));
               
            }

            playerList = PlayerBO.Display(playerList);
            

            if(playerList.Capacity != 0)
            {
                foreach (var players in playerList)
                {
                    Console.WriteLine(players);
                }
            }
            else
            {
                Console.WriteLine("No such record found");
            }
        }
    }
}
