﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enum_and_Simple_FileHandling
{
    //Enum eith default values
    /* enum direction
     {
         east,
         west,
         north,
         south
     }*/
     //override enum values
    enum direction
    {
        east = 100,
        west,
        north,
        south
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Print the value of east : " + (int)direction.east);

            //Print names of placeholders present under enum
            foreach(string d in Enum.GetNames(typeof(direction)))
            {
                Console.WriteLine(d);
            }
        }
    }
}
