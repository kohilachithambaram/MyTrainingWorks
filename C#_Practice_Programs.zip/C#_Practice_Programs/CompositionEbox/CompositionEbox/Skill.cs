﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillsData
{
    class Skill
    {
        private string _name;
        private int _experience;

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public int Experience
        {
            get
            {
                return _experience;
            }

            set
            {
                _experience = value;
            }
        }

        public Skill()
        {

        }

        public Skill(string _name, int _experience)
        {
            this._name = _name;
            this._experience = _experience;
        }

        public override string ToString()
        {
            return string.Format("{0} with {1} years of Experience",this._name,this._experience);
        }
    }
}
