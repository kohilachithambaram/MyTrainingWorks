﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillsData
{
    class Player
    {
        private string _name;
        private Skill _skill;

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        internal Skill Skill
        {
            get
            {
                return _skill;
            }

            set
            {
                _skill = value;
            }
        }

        public Player()
        {

        }

        public Player(string _name, Skill _skill)
        {
            this._name = _name;
            this._skill = _skill;
        }

        public override string ToString()
        {
            return string.Format("Player : {0} is a {1} ",this._name,this._skill);
        }
    }
}
