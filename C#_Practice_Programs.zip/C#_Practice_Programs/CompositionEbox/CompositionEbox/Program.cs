﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillsData
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Please enter the player name :");
            string name = Console.ReadLine();
            Console.WriteLine("Please enter the skill name :");
            string skillName = Console.ReadLine();
            Console.WriteLine("Please enter the years in experience :");
            int experience = int.Parse(Console.ReadLine());

            Skill skill = new Skill(skillName,experience);

            Player player = new Player(name,skill);

            Console.WriteLine("Hi BCCI. Here is the player skill details: ");

            Utility.displayPlayerSkillDetail(player);
        }
    }
}
