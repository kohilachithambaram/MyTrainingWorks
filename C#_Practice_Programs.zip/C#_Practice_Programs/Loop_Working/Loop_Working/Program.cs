﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loop_Working
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the num1");
            int num1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the num2");
            int num2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Menu:\n1.Addition\n2.Subraction\n" +
            "3.Multiplication\n4.Division\n");

            int menu = 0;
            string choice = "";
            do
            {
                Console.WriteLine("Enter your choice");
                menu = int.Parse(Console.ReadLine());

                switch(menu)
                {
                    case 1:
                        Console.WriteLine("Addition Result");
                        break;

                    case 2:
                        Console.WriteLine("Subraction Result");
                        break;

                    case 3:
                        Console.WriteLine("Multiplication Result");
                        break;

                    case 4:
                        Console.WriteLine("Division Result");
                        break;
                }

                Console.WriteLine("Do you want to continue?yes/no");
                choice = Console.ReadLine();
            }
            while (choice.Equals("yes",
            StringComparison.InvariantCultureIgnoreCase));
        }
    }
}
