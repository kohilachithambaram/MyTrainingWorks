﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Functions
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Display Instance Methods");
            Program p = new Program();
            p.Display();

            Display("Koki");

            Console.WriteLine("Return Instance Method : " + p.Display(5,3));

            Console.WriteLine("Enter the username");
            string username = Console.ReadLine();

            Console.WriteLine("Enter the password");
            string password = Console.ReadLine();

            int res = Display(username,password);
            if(res == 1)
            {
                Console.WriteLine("valid user");
            }
            else
            {
                Console.WriteLine("Invalid user");
            }
        }
            //Static Polymorphism or Early Binding
            /*To do this polymorphism we use the concept called overloading where multiple methods can be declared with same name but differentiated by arguments or datatypes*/
            public void Display()
        {
            Console.WriteLine("Instance non return method with no arg");
        }

        public static void Display(string name)
        {
            Console.WriteLine("static non return method with Name :" + name);
        }

        public int Display(int a, int b)
        {
            return a + b;
        }

        public static int Display(string username, string password)
        {
            int i = 0;
            if (username.Equals("sam", StringComparison.InvariantCultureIgnoreCase) && (password.Equals("sam@123", StringComparison.InvariantCultureIgnoreCase)))
            {
                i = 1;
            }
            return i;
        }
    }
    }

