﻿using System;
//XML File handling
using System.IO;
using System.Xml;

namespace File_handling_with_xml_data
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream(@"D:/XmlExample.xml",
              FileMode.OpenOrCreate, FileAccess.Write);
            //Create XmlWriter and tag it with fs
            XmlWriter writter = XmlWriter.Create(fs);
            //Start the xml document writing
            writter.WriteStartDocument();
            //Write start node (main node)
            writter.WriteStartElement("Employees");
            //create sub node called employee
            writter.WriteStartElement("Employee");
            writter.WriteAttributeString("Project_Assigned", "Yes");
            writter.WriteElementString("Name", "Sam");
            writter.WriteElementString("Id", "100");
            writter.WriteElementString("Salary", "5000");
            //close sub node employee
            writter.WriteEndElement();       
            //create sub node called employee
            writter.WriteStartElement("Employee");
            writter.WriteAttributeString("Project_Assigned", "No");
            writter.WriteElementString("Name", "Sam");
            writter.WriteElementString("Id", "100");
            writter.WriteElementString("Salary", "5000");
            //close sub node employee
            writter.WriteEndElement();
            //Close the main node
            writter.WriteEndElement();
            //Stop the xml document writing
            writter.WriteEndDocument();
            writter.Close();
            fs.Close();
            Console.WriteLine("XML document creation completed");
            //Read data from xml in console environment
            FileStream fs1 = new FileStream(@"D:/XmlExample.xml",
              FileMode.OpenOrCreate, FileAccess.Read);
            //Create XmlReader
            XmlReader reader = XmlReader.Create(fs1);
            //read() data from xml file
            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element: //here we are reading the node elements
                        Console.WriteLine("<" + reader.Name + ">");
                        break;
                    case XmlNodeType.Text: //ie data under element
                        Console.WriteLine(reader.Value);
                        break;
                    case XmlNodeType.EndElement:
                        Console.WriteLine("</" + reader.Name + ">");
                        break;
                }
            }

            reader.Close();
            fs1.Close();
            Console.WriteLine("Reading completed");
        }
    }
}







