﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variables_and_Operators
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program ();
            Console.WriteLine("Please enter the first number");
            int a = int.Parse(Console.ReadLine());

            Console.WriteLine("Please enter the second number");
            int b = int.Parse(Console.ReadLine());

            int result = p.addition(a, b);
            Console.WriteLine("The sum of the 2 numbers is " + result);
        }

        public int addition(int a , int b)
        {
            return a + b;
        }
    }
}
