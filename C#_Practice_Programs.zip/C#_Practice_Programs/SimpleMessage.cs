using System;
class SimpleMessage
{
	static void Main()
	{
		Console.WriteLine("Hello World");
	}
}