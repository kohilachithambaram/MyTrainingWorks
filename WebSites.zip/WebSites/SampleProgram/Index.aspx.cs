﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Auto execution of code when page is loaded in browser
        textDisplay.Text = "Welcome User";
    }

    protected void clickMeButton_Click(object sender, EventArgs e)
    {
        //clickMeButton.Text = "Click Control";
        //Change the text when the user clicks the button
        textDisplay.Text = "Hello User";
        Response.Write("Today date: " + DateTime.Now.ToString("dd/MM/yyyy"));
    }

    protected void popupBtn_Click(object sender, EventArgs e)
    {
        //ASP.NET (Server side script)
        string current_time = DateTime.Now.ToString("hh:mm:ss");
        Response.Write("<script>alert('Current Time : "+current_time+"')</script>");
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void btnRedirect_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }

    protected void btnMessageRedirect_Click(object sender, EventArgs e)
    {
        string userMessage = "Welcome to Login Page";
        Response.Write("<script>alert('Message : " + userMessage + "');"+
            "window.location.href = 'Login.aspx';</script>");
    }

    protected void btnTransfer_Click(object sender, EventArgs e)
    {
        Server.Transfer("Login.aspx");
    }
}