﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class Display : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DisplayData();
    }

    static string callConnection = ConfigurationManager.ConnectionStrings["db_connection"].ConnectionString;
    //All Query should be declared under global variable
    static string displayJoin = "select em_name as Name,emp_joining_year as [Joining Year],de_name as Department from employee join department on employee.de_em_id = department.de_id";

    public void DisplayData()
    {
        using (SqlConnection con = new SqlConnection(callConnection))
        {

            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = displayJoin;

            //Take a DataAdapter to extract all data ; ie execute the command under the DataAdapter
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            //Take a DataSet to store the data loaclly
            DataSet ds = new DataSet();
            //push data into dataset
            da.Fill(ds);

            //Tell the GridView which is the datasource to collect data
            GridView1.DataSource = ds;
            //bind the data to GridView
            GridView1.DataBind();
        }
    }
}
