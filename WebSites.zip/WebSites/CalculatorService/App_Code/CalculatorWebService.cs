﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for CalculatorWebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class CalculatorWebService : System.Web.Services.WebService
{

    public CalculatorWebService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod] //this decorator is used to describe a method as web service method
    public int Addition(int a , int b)
    {
        return a + b;
    }

    [WebMethod]
    public int Subraction(int a , int b)
    {
        if (a > b)
            return a - b;
        else
            return b - a;
    }

}
