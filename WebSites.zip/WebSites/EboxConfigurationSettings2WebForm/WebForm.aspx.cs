﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class WebForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnGetData_Click(object sender, EventArgs e)
    {
        try
        {
            EboxServiceReference1.EboxService1SoapClient client = new EboxServiceReference1.EboxService1SoapClient();
            lblGetData.Text = client.HelloWorld();
        }
        catch (Exception ex)
        {

            Console.WriteLine(ex.Message);
        }
        finally
        {
            Response.Redirect("FormBug.aspx");
        }
    }
}