﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//add a namespace to access data from we.config file
using System.Configuration; 

public partial class Calculator : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //call teh data from appSettings via the key
        string batchInfo = ConfigurationManager.AppSettings["BatchName"].ToString();
        Response.Write("Site Manager : " + batchInfo);
    }

    protected void btnAddition_Click(object sender, EventArgs e)
    {
        try
        {
            int number1 = int.Parse(txtNumber1.Text);
            int number2 = int.Parse(txtNumber2.Text);
            int result = 0;
            CalService.CalculatorWebServiceSoapClient client = new CalService.CalculatorWebServiceSoapClient();
            result = client.Addition(number1,number2);
            //int result = Addition(number1, number2);
            txtResult.Text = result.ToString();
        }
        catch(Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            //While your site is not complete give some errors in the page so that when button is clicked it goes to the site maintainance page
            //Response.Redirect("FormBug.aspx");
        }
    }


    protected void btnSubraction_Click(object sender, EventArgs e)
    {
        try
        {
            int number1 = int.Parse(txtNumber1.Text);
            int number2 = int.Parse(txtNumber2.Text);
            int result = 0;
            CalService.CalculatorWebServiceSoapClient client = new CalService.CalculatorWebServiceSoapClient();
            result = client.Subraction(number1, number2);
            //int result = Addition(number1, number2);
            txtResult.Text = result.ToString();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            //While your site is not complete give some errors in the page so that when button is clicked it goes to the site maintainance page
            //Response.Redirect("FormBug.aspx");
        }
    }
}