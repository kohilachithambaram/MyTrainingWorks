﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack) // Tells the compiler not to do any work on below code for postback or reload
        {
            
            //when you add a data to dropdown add under !PostBack Section
            List<string> departmentList = new List<string>();
            departmentList.Add("Select..");
            departmentList.Add("CSE");
            departmentList.Add("IT");
            departmentList.Add("EEE");
            departmentList.Add("ECE");

            //Add the data to dropdownlist
            ddlDepartment.DataSource = departmentList;
            //DataSource property tells the compiler where to look for data that should be bounded to the dropdown control
            ddlDepartment.DataBind();
            //DataBind property is used to bind the data under dropdown collected from the datasource
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblDisplay.Text = "Your Selected Department is " + ddlDepartment.SelectedItem.Text;
    }
}