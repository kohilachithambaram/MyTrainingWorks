﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack) // Tells the compiler not to do any work on below code for postback or reload
        {
            //Initially the button should be inactive
            btnRegister.Enabled = false;

            //when you add a data to dropdown add under !PostBack Section
            List<string> stateList = new List<string>();
            stateList.Add("Select");
            stateList.Add("TamilNadu");
            stateList.Add("Kerala");
            stateList.Add("Andhra Pradesh");
            stateList.Add("Karnataka");

            //Add the data to dropdownlist
            ddlState.DataSource = stateList;
            //DataSource property tells the compiler where to look for data that should be bounded to the dropdown control
            ddlState.DataBind();
            //DataBind property is used to bind the data under dropdown collected from the datasource
        }
    }

    //The checkbox is checked event determined whether button is to be activated or not
    protected void chkAgreement_CheckedChanged(object sender, EventArgs e)
    {
        if(chkAgreement.Checked == true)
            //ie user clicks on the checkbox
        {
            btnRegister.Enabled = true;
        }
        else
        {
            btnRegister.Enabled = false;
        }
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        try
        {
            //Response.Write("Registration Button");
            //Add data to xml file
            //(1)create an XMLDocument object
            XmlDocument doc = new XmlDocument();
            //(2)Load the xml file that you have just created
            doc.Load(Server.MapPath("Customers.xml"));
            //(3)select the root node from xml under which ypu craete child nodes
            XmlNode rootNode = doc.SelectSingleNode("CustomerDetail");
            //(4) create child nodes called customer
            XmlNode childNode = rootNode.AppendChild(doc.CreateNode(XmlNodeType.Element,"Customer", ""));
            //(5)Add elements like username , password etc to the child node
            childNode.AppendChild(doc.CreateNode(XmlNodeType.Element,"username","")).InnerText=txtUsername.Text;
            childNode.AppendChild(doc.CreateNode(XmlNodeType.Element, "password", "")).InnerText = txtPassword.Text;
            childNode.AppendChild(doc.CreateNode(XmlNodeType.Element, "email", "")).InnerText = txtEmail.Text;
            childNode.AppendChild(doc.CreateNode(XmlNodeType.Element, "phone", "")).InnerText = txtPhone.Text;
            childNode.AppendChild(doc.CreateNode(XmlNodeType.Element, "address", "")).InnerText = txtAddress.Text;
            childNode.AppendChild(doc.CreateNode(XmlNodeType.Element, "gender", "")).InnerText = lblGenderSelected.Text;
            childNode.AppendChild(doc.CreateNode(XmlNodeType.Element, "dob", "")).InnerText = txtDob.Text;
            childNode.AppendChild(doc.CreateNode(XmlNodeType.Element, "states", "")).InnerText = ddlState.SelectedItem.Text;
            //(6)write the data back to xml file
            doc.Save(Server.MapPath("Customers.xml"));
            Response.Write("<script>alert('Customer Registered Successfully');" + "window.location.href='Home.aspx'</script>");
        }
        catch(Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }

    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Select the item under DropDown and display under Label
        lblDisplay.Text = "Your Selected State is " + ddlState.SelectedItem.Text;
        //The SelectedItem.Text will display the item selected from dropdown
    }

    protected void radioMale_CheckedChanged(object sender, EventArgs e)
    {
        if (radioMale.Checked == true)
        {
            radioFemale.Checked = false;
            lblGenderSelected.Text = radioMale.Text;
        }
    }

    protected void radioFemale_CheckedChanged(object sender, EventArgs e)
    {
        if (radioFemale.Checked == true)
        {
            radioMale.Checked = false;
            lblGenderSelected.Text = radioFemale.Text;
        }
    }
}