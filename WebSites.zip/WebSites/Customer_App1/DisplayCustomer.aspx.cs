﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//use namespace to call xml data
using System.Xml;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Call the username name under !PostBack to retain the data
        if(!Page.IsPostBack)
        {
            Label2.Text = Session["username"].ToString();
            //call the displayData() under Postback of page load
            displayData();
        }

        
    }

    protected void displayData()
    {
        //this funcation will contain the code to display the data in grid view
        //(1)Take a DataSet which is a container to hold xml records or sql tables to do operations locally
        //ada the namespace System.Data to use the DataSet
        DataSet ds = new DataSet();
        //use ReadXml() method to read data from xml file and store it on local dataset
        ds.ReadXml(Server.MapPath("Customers.xml"));
        //Tell the compiler what is the data container from where gridview will collect the data
        gridCustomer.DataSource = ds;
        //Bind the data of dataset to gridview
        gridCustomer.DataBind();
    }


    protected void EditRecord_gridCustomer(object sender, GridViewEditEventArgs e)
    {
        //Open textboxes for in grid view for editing data
        //Find the record that you want tio edit and opens textboxes for that row
        gridCustomer.EditIndex = e.NewEditIndex;
        //EditIndex property will search for the row which needs the textboxes for edit purpose
        displayData();
    }

    protected void CancelEdit_gridCsutomer(object sender, GridViewCancelEditEventArgs e)
    {

        //cancel edit and display a normal gridview
        gridCustomer.EditIndex = -1;
        //-1 in EditIndex will restore grid from edit view to normal display view
        displayData();
    }


    protected void UpdateRecord_gridCustomer(object sender, GridViewUpdateEventArgs e)
    {
        //Update data present under textboxes in gridview
        //(1)Create a row under which you want to keep all your records for update work
        GridViewRow row = (GridViewRow)gridCustomer.Rows[e.RowIndex];
        //create a row with the row information from gridCustomer that you want to update

        //To reach the row navigate through data rows in gridview and tell the compiler which row is getting updated from gridview
        int row_count = gridCustomer.Rows[e.RowIndex].DataItemIndex;

        //create textboxes to store grid info for update (or name Grid Textboxes)
        TextBox usernameTextbox = (TextBox)row.Cells[0].Controls[0];
        //usernameTextBox.ReadOnly = true;
        //So under the row which you want to update the first column will have cell no = 0 and a single control[control = 0]
        TextBox passwordTextBox = (TextBox)row.Cells[1].Controls[0];
        TextBox emailTextBox = (TextBox)row.Cells[2].Controls[0];
        TextBox phoneTextBox = (TextBox)row.Cells[3].Controls[0];
        TextBox addressTextBox = (TextBox)row.Cells[4].Controls[0];
        TextBox genderTextBox = (TextBox)row.Cells[5].Controls[0];
        TextBox dobTextBox = (TextBox)row.Cells[6].Controls[0];
        TextBox statesTextBox = (TextBox)row.Cells[7].Controls[0];

        //Also provide facility to move the grid to display mode once update is done or cancel is done
        gridCustomer.EditIndex = -1;
        displayData();

        //Update data in xml file that you will update from grid
        //create a local storage dataset which collects data from grid to update
        DataSet ds = gridCustomer.DataSource as DataSet;
        //The dataset will contain a table structure; 
        //this table will contain grid data so go to the row whose data you want to update and select the column ie  xml element name 
        //ds.Tables[0].Rows[row_count]["username"] = usernameTextBox.Text;
        ds.Tables[0].Rows[row_count]["password"] = passwordTextBox.Text;
        ds.Tables[0].Rows[row_count]["email"] = emailTextBox.Text;
        ds.Tables[0].Rows[row_count]["phone"] = phoneTextBox.Text;
        ds.Tables[0].Rows[row_count]["address"] = addressTextBox.Text;
        ds.Tables[0].Rows[row_count]["gender"] = genderTextBox.Text;
        ds.Tables[0].Rows[row_count]["dob"] = dobTextBox.Text;
        ds.Tables[0].Rows[row_count]["states"] = statesTextBox.Text;

        //Write updated data back to xml file 
        ds.WriteXml(Server.MapPath("Customers.xml"));
        Response.Write("Customer with username name = " + usernameTextbox.Text + " is Updated Successfully");
        displayData();
    }

    protected void DeleteRecord_gridCustomer(object sender, GridViewDeleteEventArgs e)
    {
        displayData();
        //Delete record from xml or sql 
        //store GridData in local DataSet
        DataSet ds = gridCustomer.DataSource as DataSet;
        //Find and delete data by its row number
        ds.Tables[0].Rows[gridCustomer.Rows[e.RowIndex].DataItemIndex].Delete();
        //Write the delete in xml      
        ds.WriteXml(Server.MapPath("Customers.xml"));
        Response.Write("<script>alert('Data Deleted')</script>");
        displayData();
    }
}