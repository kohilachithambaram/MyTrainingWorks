﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //call the displayData() under Postback of page load
            displayData();
        }
    }

    protected void displayData()
    {
        //this funcation will contain the code to display the data in grid view
        //(1)Take a DataSet which is a container to hold xml records or sql tables to do operations locally
        //ada the namespace System.Data to use the DataSet
        DataSet ds = new DataSet();
        //use ReadXml() method to read data from xml file and store it on local dataset
        ds.ReadXml(Server.MapPath("Students.xml"));
        //Tell the compiler what is the data container from where gridview will collect the data
        gridStudent.DataSource = ds;
        //Bind the data of dataset to gridview
        gridStudent.DataBind();
    }
    protected void CancelEdit_gridStudent(object sender, GridViewCancelEditEventArgs e)
    {
        //cancel edit and display a normal gridview
        gridStudent.EditIndex = -1;
        //-1 in EditIndex will restore grid from edit view to normal display view
        displayData();
    }

    protected void EditRecord_gridStudent(object sender, GridViewEditEventArgs e)
    {
        //Open textboxes for in grid view for editing data
        //Find the record that you want tio edit and opens textboxes for that row
        gridStudent.EditIndex = e.NewEditIndex;
        //EditIndex property will search for the row which needs the textboxes for edit purpose
        displayData();
    }

    protected void UpdateRecord_gridStudent(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = (GridViewRow)gridStudent.Rows[e.RowIndex];
        int row_count = gridStudent.Rows[e.RowIndex].DataItemIndex;
        TextBox usernameTextbox = (TextBox)row.Cells[0].Controls[0];
        TextBox departmentTextBox = (TextBox)row.Cells[1].Controls[0];
        gridStudent.EditIndex = -1;
        displayData();
        DataSet ds = gridStudent.DataSource as DataSet;
        ds.Tables[0].Rows[row_count]["department"] = departmentTextBox.Text;
        ds.WriteXml(Server.MapPath("Students.xml"));
        Response.Write("Student with Name " + usernameTextbox.Text + " is Updated Successfully");
        displayData();
    }
}