create database moviecruiser1;
use moviecruiser1;

CREATE TABLE [dbo].[user](
       [us_id] [bigint] IDENTITY(1,1) NOT NULL,
       [us_name] [varchar](100) NULL,
       [us_password] [varchar](100) unique,
       [us_phone] [bigint],
       [us_active] [varchar](60),
CONSTRAINT [PK_user] PRIMARY KEY CLUSTERED 
(
       [us_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

sp_help [user];

create table favorite(
	fv_id bigint IDENTITY(101,1) NOT NULL,
	fv_us_id bigint NULL,
	fv_mv_id bigint NULL,
	CONSTRAINT PK_favorite PRIMARY KEY(fv_id));

sp_help favorite;

create table movie(
	mv_id bigint IDENTITY(1001,1) NOT NULL,
	mv_title varchar(100) NULL,
	mv_budget decimal(12,2) NULL,
	mv_active varchar(3) NULL,
	mv_date_of_launch date NULL,
	mv_genre varchar(100) NULL,
	mv_has_teaser varchar(3) NULL,
	CONSTRAINT PK_movie PRIMARY KEY(mv_id));

alter table favorite ADD CONSTRAINT fv_us_id_fk FOREIGN KEY(fv_us_id) REFERENCES [user](us_id) on delete cascade on update cascade;
alter table favorite ADD CONSTRAINT fv_mv_id_fk FOREIGN KEY(fv_mv_id) REFERENCES movie(mv_id) on delete cascade on update cascade;

create table [dbo].[admin]
(
[ad_id] [bigint] IDENTITY(1001,1) NOT NULL,
[ad_password] [varchar](100) unique,
constraint ad_id_pk primary key(ad_id)
);

sp_help [admin];

insert into admin values
('admin1'),
('admin2'),
('admin3');

/*1.View Movie List Admin*/
insert into movie values('Avengers',356000000.00,'Yes','04/26/2020','Action','Yes'),
('Aladdin',183000000.00,'Yes','05/24/2019','Adventure','No'),
('Captain Marvel',175000000.00,'Yes','08/03/2019','Action','No'),
('The Lion King',175000000.00,'No','07/17/2019','Animation','Yes'),
('First Man',70000000.00,'Yes','08/29/2022','Adventure','Yes');

select mv.mv_id,mv.mv_title,mv.mv_budget,mv.mv_active,mv.mv_date_of_launch,mv.mv_genre,mv.mv_has_teaser 
from movie as mv;

/*2.View Movie List Customer*/
select mv.mv_id,mv.mv_title,mv.mv_budget,mv.mv_active,mv.mv_date_of_launch,mv.mv_genre,mv.mv_has_teaser 
from movie as mv 
where mv.mv_active = 'Yes' and mv.mv_date_of_launch > GETDATE();

/*3.Edit Movie*/
select mv.mv_id,mv.mv_title,mv.mv_budget,mv.mv_active,mv.mv_date_of_launch,mv.mv_genre,mv.mv_has_teaser 
from movie as mv 
where mv.mv_id = 1004;

update movie set 
mv_title = 'Black Widow',
mv_budget = 135000000.00,
mv_active = 'Yes',
mv_date_of_launch = '09/15/2023',
mv_genre = 'Action',
mv_has_teaser = 'Yes'
where mv_id = 1002;

select mv.mv_id,mv.mv_title,mv.mv_budget,mv.mv_active,mv.mv_date_of_launch,mv.mv_genre,mv.mv_has_teaser 
from movie as mv;

/*4.Add to Favorite */
insert into [user] values ('Admin'),
('Customer');

select us.us_id , us.us_name 
from [user] as us;

insert into favorite values(2,1001),
(2,1002),
(2,1005);

select fv.fv_id , fv.fv_us_id , fv.fv_mv_id from favorite as fv;

/*5.View Favorite*/
select mv.mv_title,mv.mv_has_teaser,mv.mv_budget 
from movie as mv join favorite fv
on mv.mv_id = fv.fv_mv_id; 

select sum(mv.mv_budget)
from movie as mv join favorite fv
on mv.mv_id = fv.fv_mv_id; 

/*6.Remove Movie from Favorite*/
delete from favorite where fv_us_id = 2 and fv_mv_id = 1002;
select fv.fv_id , fv.fv_us_id , fv.fv_mv_id from favorite as fv;

select * from [admin];
select * from [user];
select * from movie;
select * from favorite;


