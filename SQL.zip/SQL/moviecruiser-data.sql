/*1.View Movie List Admin*/
insert into movie values('Avengers',356000000.00,'Yes','04/26/2020','Action','Yes'),
('Aladdin',183000000.00,'Yes','05/24/2019','Adventure','No'),
('Captain Marvel',175000000.00,'Yes','08/03/2019','Action','No'),
('The Lion King',175000000.00,'No','07/17/2019','Animation','Yes'),
('First Man',70000000.00,'Yes','08/29/2022','Adventure','Yes');

select mv.mv_id,mv.mv_title,mv.mv_budget,mv.mv_active,mv.mv_date_of_launch,mv.mv_genre,mv.mv_has_teaser 
from movie as mv;

/*2.View Movie List Customer*/
select mv.mv_id,mv.mv_title,mv.mv_budget,mv.mv_active,mv.mv_date_of_launch,mv.mv_genre,mv.mv_has_teaser 
from movie as mv 
where mv.mv_active = 'Yes' and mv.mv_date_of_launch > GETDATE();

/*3.Edit Movie*/
select mv.mv_id,mv.mv_title,mv.mv_budget,mv.mv_active,mv.mv_date_of_launch,mv.mv_genre,mv.mv_has_teaser 
from movie as mv 
where mv.mv_id = 1004;

update movie set 
mv_title = 'Black Widow',
mv_budget = 135000000.00,
mv_active = 'Yes',
mv_date_of_launch = '09/15/2023',
mv_genre = 'Action',
mv_has_teaser = 'Yes'
where mv_id = 1002;

select mv.mv_id,mv.mv_title,mv.mv_budget,mv.mv_active,mv.mv_date_of_launch,mv.mv_genre,mv.mv_has_teaser 
from movie as mv;

/*4.Add to Favorite */
insert into [user] values ('Admin'),
('Customer');

select us.us_id , us.us_name 
from [user] as us;

insert into favorite values(2,1001),
(2,1002),
(2,1005);

select fv.fv_id , fv.fv_us_id , fv.fv_mv_id from favorite as fv;

/*5.View Favorite*/
select mv.mv_title,mv.mv_has_teaser,mv.mv_budget 
from movie as mv join favorite fv
on mv.mv_id = fv.fv_mv_id; 

select sum(mv.mv_budget)
from movie as mv join favorite fv
on mv.mv_id = fv.fv_mv_id; 

/*6.Remove Movie from Favorite*/
delete from favorite where fv_us_id = 2 and fv_mv_id = 1002;
select fv.fv_id , fv.fv_us_id , fv.fv_mv_id from favorite as fv;