sp_help menu_item;
sp_help cart;

/*1.View Menu Item List Admin*/
insert into menu_item values('Sandwich',99.00,'Yes','03/15/2017','Main Course','Yes'),
('Burger', 129.00,'Yes','12/23/2017', 'Main Course','No'),
('Pizza',149.00,'Yes','08/21/2018', 'Main Course','No'),
('French Fries', 57.00,'No','07/02/2017', 'Starters','Yes'),
('Chocholate Brownie', 32.00,'Yes','11/02/2022', 'Dessert','Yes');
select me.me_name,me.me_price,me.me_active,me.me_date_of_launch,me.me_category,me.me_free_delivery from menu_item as me;

/*2.View Menu Item List Customer*/
select me.me_name,me.me_price,me.me_active,me.me_date_of_launch,me.me_category,me.me_free_delivery from menu_item as me where me.me_date_of_launch > getdate() and me.me_active = 'Yes';

/*3.Edit Menu Item */
select me.me_name,me.me_price,me.me_active,me.me_date_of_launch,me.me_category,me.me_free_delivery from menu_item as me where me.me_id = 3;

update menu_item set 
me_name = 'Momos', 
me_price = 35.00 , 
me_active = 'No' , 
me_date_of_launch = '07/23/2020' , 
me_category = 'Starters' , 
me_free_delivery = 'Yes' where me_id = 3;

/*4.Add to Cart */
insert into [dbo].[user] values ('Admin'),('Customer');
select us.us_name from [dbo].[user] as us;

update menu_item set me_date_of_launch = '03/15/2023' where me_id = 1;
update menu_item set me_active='Yes' where me_id = 3;

/*insert into cart values(2,1),
(2,3),
(2,5);
select * from cart;

drop table cart;*/

select identity(int) as ct_id,u.us_id as ct_us_id,m.me_id as ct_pr_id
into cart
from [user] u,menu_item m
where m. me_active = 'yes' and m.me_date_of_launch > GETDATE() and u.us_id=1;

alter table cart add constraint ct_id_pk primary key(ct_id);
alter table cart add constraint ct_us_id_fk foreign key(ct_us_id) references [user](us_id) on delete cascade on update cascade;
alter table cart add constraint ct_pr_id_fk foreign key(ct_pr_id) references menu_item(me_id) on delete cascade on update cascade;

select ct.ct_us_id,ct.ct_pr_id from cart as ct;

/*5.View Cart */
select me.me_name,me.me_free_delivery,me.me_price 
from menu_item as me 
join cart as ct 
on me.me_id = ct.ct_pr_id;

select sum(me.me_price) as Total
from menu_item as me 
join cart as ct 
on me.me_id = ct.ct_pr_id;

/*6.Remove Item from Cart */
delete from cart where ct_us_id = 1 and ct_pr_id = 5; 
