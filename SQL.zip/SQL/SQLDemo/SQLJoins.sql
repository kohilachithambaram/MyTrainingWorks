select * from batch;
select * from trainee;

/*Find the batches thata can be assigned to any trainee*/
select batchId,empname from batch, trainee;

/*Display Employee name , Phone , Email , BatchId and Batchtype the trainee is taking training*/
select empname,phone,email,b.batchId,batchtype 
from trainee tr join batchdetails bd 
on tr.EmpId = bd.TraineeId join batch b 
on b.BatchId = bd.BatchId;

/*Display trainee info who are allocated a batch and also not allocated a batch*/
/*Left outer join*/
select * from trainee tr left outer join batchdetails bd 
on tr.EmpId = bd.TraineeId left outer join batch b
on b.BatchId = bd.BatchId;

/*Display trainee info who are allocated a batch.Display all batches even if there is no trainee*/
/*Right outer join*/
select * from trainee tr right outer join batchdetails bd 
on tr.EmpId = bd.TraineeId right outer join batch b
on b.BatchId = bd.BatchId;

/*Display all trainees info and all batches info even if there is no common data*/
/*Right outer join*/
select * from trainee tr full outer join batchdetails bd 
on tr.EmpId = bd.TraineeId full outer join batch b
on b.BatchId = bd.BatchId;

alter table trainee add PocId int;
update trainee set PocId = 1002 ;
update trainee set PocId = 1001 where EmpId = 1004;
update trainee set PocId = null where EmpId = 1001;
update trainee set PocId = null where EmpId = 1002;

/*Display the empId and name of person who is working as POC*/
select distinct emp1.empid,emp1.empname 
from trainee emp1 join trainee emp2
on emp1.empid = emp2.pocId;

sp_help trainee;
