/*SubQuery*/
select * from trainee;
select * from batch;

select distinct EmpId,Empname 
from trainee where EmpId IN
(select distinct PocId from trainee where PocId is not null);

/*Display the batchowner name and the number of batches the batchowner is handling only for the batchowner handling the highest number of batches*/
select batchOwner,count(BatchOwner) as batchCount
from batch
group by batchOwner
having count(BatchOwner) >=ALL 
(select count(BatchOwner) as batchCount
from batch
group by batchOwner);

/*Display the batchowner name and the number of batches the batchowner is handling only for the batchowner who is handling batches greater than min count*/
select batchOwner,count(BatchOwner) as batchCount
from batch
group by batchOwner
having count(BatchOwner) >ANY 
(select count(BatchOwner) as batchCount
from batch
group by batchOwner);

/*Display the batchowner name , location , technology , training duration for batchowner with highest batchcount*/
/*Nested SubQuery*/
select b.batchOwner,bb.location,b.Technology,bb.TrainingDuration
from batch b join batchDetails bb
on b.BatchId = bb.BatchId
where BatchOwner IN
(select BatchOwner
from batch
group by batchOwner
having count(BatchOwner) >= ALL(select count(BatchOwner) from batch
group by BatchOwner));