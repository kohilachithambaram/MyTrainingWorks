select * from role;
select * from [dbo].[user];

/*1*/
select * from role as r inner join [dbo].[user] as u
on r.id = u.id
order by r.name,u.name;

/*2*/
select  u.username, r.name from role as r join [dbo].[user] as u
on r.id = u.id
where r.id IN 
(select u.id from [dbo].[user] as u ) order by u.username;

/*1*/
select * from [dbo].[user];
select * from post;

select u.name , count(p.[user_id]) as postCount from [dbo].[user] as u
join post as p
on u.id = p.[user_id]
group by u.name;

/*2*/
select * from [dbo].[user];
select * from [dbo].[event];

select u.name , count(e.organiser_id) as eventCount from [dbo].[user] as u
join [dbo].[event] as e
on u.id = e.organiser_id
group by u.name;
