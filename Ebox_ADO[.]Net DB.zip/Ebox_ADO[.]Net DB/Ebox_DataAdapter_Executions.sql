use EboxDB;
create table trainee
(
tr_id int not null,
tr_name varchar(100),
tr_email varchar(100),
tr_joining_year int,
de_tr_id int,
constraint tr_id_pk primary key(tr_id),
constraint de_tr_fk foreign key(de_tr_id) references 
department(de_id)
on delete cascade on update cascade
);

insert into trainee values
(1001,'Sekhar','sekhar@cognizant.com',2014,2),
(1002,'Kishore','kishore@cognizant.com',2015,1),
(1003,'Merry','merryR@cognizant.com',2014,2),
(1004,'Joe','joeM@cognizant.com',2017,3),
(1005,'Sam','samG@cognizant.com',2014,2),
(1006,'Trisha','trishaD@cognizant.com',2015,3),
(1007,'Deblina','deblina123@cognizant.com',2015,2),
(1008,'Peter','peterR@cognizant.com',2017,4),
(1009,'Murgan','murganG@cognizant.com',2015,3),
(1010,'Rekha','rekhaS@cognizant.com',2014,1);

select * from trainee;
sp_help trainee;


select * from trainee join department on de_tr_id = de_id;
