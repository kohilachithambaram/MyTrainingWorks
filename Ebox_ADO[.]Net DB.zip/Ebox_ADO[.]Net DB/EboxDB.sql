create database EboxDB;
use EboxDB;

create table department
(
de_id int not null,
de_name varchar(100),
constraint de_id_pk primary key(de_id)
);

insert into department values
(1,'ECE'),
(2,'EEE'),
(3,'Mechanical'),
(4,'IT'),
(5,'CSE');

select * from department;