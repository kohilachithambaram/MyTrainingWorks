create database DMCM;
use DMCM;

CREATE TABLE patient(
		pt_id as CAST('PAT'+RIGHT('000'+CAST(pt_RowNum AS Varchar(3)),3) AS Varchar(30)) PERSISTED,
		pt_first_name varchar(50) NOT NULL,
		pt_last_name varchar(50) NOT NULL,
		pt_age numeric(2) NOT NULL,
		pt_gender varchar(10) NULL,
		pt_Dob varchar(10) NULL,
		pt_phone numeric(10) NOT NULL,
		pt_altphone numeric(10) NULL,
		pt_email varchar(50) NOT NULL,
		pt_password varchar(15) NOT NULL,
		pt_address_line1 varchar(100) NOT NULL,
		pt_address_line2 varchar(100) NULL,
		pt_city varchar(50) NOT NULL,
		pt_state varchar(50) NOT NULL,
		pt_zipcode numeric(10) NOT NULL,

		pt_RowNum int IDENTITY(1,1) NOT NULL,
		CONSTRAINT PK_patient PRIMARY KEY(pt_id)
		);

CREATE TABLE doctor(
		do_id as CAST('DOC'+RIGHT('000'+CAST(do_RowNum AS Varchar(3)),3) AS Varchar(30)) PERSISTED,
		do_first_name varchar(50) NOT NULL,
		do_last_name varchar(50) NOT NULL,
		do_age numeric(2) NOT NULL,
		do_gender varchar(10) NULL,
		do_Dob varchar(10) NULL,
		do_phone numeric(10) NOT NULL,
		do_altphone numeric(10) NULL,
		do_email varchar(50) NOT NULL,
		do_password varchar(15) NOT NULL,
		do_address_line1 varchar(100) NOT NULL,
		do_address_line2 varchar(100) NULL,
		do_city varchar(50) NOT NULL,
		do_state varchar(50) NOT NULL,
		do_zipcode numeric(10) NOT NULL,
		do_degree varchar(50) NOT NULL,
		do_speciality varchar(50) NOT NULL,
		do_work_hours numeric(5) NOT NULL,
		do_clinic_name varchar(100) NOT NULL,
		do_medicare_service_id numeric(10),

		do_RowNum int IDENTITY(1,1) NOT NULL,
		CONSTRAINT PK_doctor PRIMARY KEY(do_id)
		);

CREATE TABLE [admin](
		ad_id as CAST('AD'+RIGHT('000'+CAST(ad_RowNum AS Varchar(3)),3) AS Varchar(30)) PERSISTED,
		ad_first_name varchar(50) NOT NULL,
		ad_last_name varchar(50) NOT NULL,
		ad_age numeric(2) NOT NULL,
		ad_gender varchar(10) NOT NULL,
		ad_Dob varchar(10) NOT NULL,
		ad_phone numeric(10) NOT NULL,
		ad_altphone numeric(10) NULL,
		ad_email varchar(50) NOT NULL,
		ad_password varchar(15) NOT NULL,

		ad_RowNum int IDENTITY(1,1) NOT NULL,
		CONSTRAINT PK_admin PRIMARY KEY(ad_id)
		);

CREATE TABLE medicare_services(
		ms_id numeric(10) IDENTITY(1,1) NOT NULL,
		ms_service varchar(50) NOT NULL,
		ms_description varchar(200) NOT NULL,
		ms_amount numeric(10) NOT NULL,
		
		CONSTRAINT PK_medicare PRIMARY KEY(ms_id) 
);

CREATE TABLE medical_test_history(
		mth_id numeric(10) IDENTITY(1,1) NOT NULL,
		mth_pt_id varchar(30),
		mth_do_id varchar(30),
		mth_ms_id numeric(10),
		mth_service_date date NULL,
		mth_test_result_date date NULL,
		mth_diag1_actual_value numeric(10),
		mth_diag1_normal_range numeric(10),
		mth_diag2_actual_value numeric(10) NULL,
		mth_diag2_normal_range numeric(10) NULL,
		mth_diag3_actual_value numeric(10) NULL,
		mth_diag3_normal_range numeric(10) NULL,
		mth_diag4_actual_value numeric(10) NULL,
		mth_diag4_normal_range numeric(10) NULL,
		mth_diag5_actual_value numeric(10) NULL,
		mth_diag5_normal_range numeric(10) NULL,
		mth_diag6_actual_value numeric(10) NULL,
		mth_diag6_normal_range numeric(10) NULL,
		mth_doctors_comments varchar(100) NULL,
		mth_other_info varchar(300) NULL 

		CONSTRAINT PK_test_history PRIMARY KEY(mth_id) 
);

CREATE TABLE appointment(
	ap_id numeric(10) IDENTITY(1,1) NOT NULL,
	ap_pt_id varchar(30),
	ap_do_id varchar(30),
	ap_ms_id numeric(10),
	ap_date date,
	ap_status varchar(20)

	CONSTRAINT PK_appointment PRIMARY KEY(ap_id) 
);

alter table medical_test_history ADD CONSTRAINT mth_pt_id_fk FOREIGN KEY(mth_pt_id) REFERENCES [patient](pt_id) on delete cascade on update cascade;
alter table medical_test_history ADD CONSTRAINT mth_do_id_fk FOREIGN KEY(mth_do_id) REFERENCES [doctor](do_id) on delete cascade on update cascade;
alter table medical_test_history ADD CONSTRAINT mth_ms_id_fk FOREIGN KEY(mth_ms_id) REFERENCES [medicare_services](ms_id) on delete cascade on update cascade;

alter table doctor ADD CONSTRAINT do_ms_id_fk FOREIGN KEY(do_medicare_service_id) REFERENCES [medicare_services](ms_id) on delete no action on update no action;

alter table appointment ADD CONSTRAINT ap_pt_id_fk FOREIGN KEY(ap_pt_id) REFERENCES [patient](pt_id) on delete cascade on update cascade;
alter table appointment ADD CONSTRAINT ap_do_id_fk FOREIGN KEY(ap_do_id) REFERENCES [doctor](do_id) on delete cascade on update cascade;
alter table appointment ADD CONSTRAINT ap_ms_id_fk FOREIGN KEY(ap_ms_id) REFERENCES [medicare_services](ms_id) on delete cascade on update cascade;

drop table patient;
drop table doctor;
drop table [admin];
drop table medicare_services;
drop table medical_test_history;
sp_help patient;
sp_help doctor;
sp_help medicare_services;
sp_help medical_test_history;
sp_help appointment;

select * from [admin];	
select * from doctor;
select * from patient;
select * from appointment;
select * from medicare_services;



select do.do_id,do.do_first_name,ap.ap_date,ap.ap_status from doctor do inner join appointment ap on do.do_id = ap.ap_do_id;
insert into medicare_services values('sdasdas','asdadas',90);
insert into medicare_services values('Surgeon','He does operation',45);
insert into medicare_services values('Dentist','He works on tooth problems',50);
insert into medicare_services values('Nuero','He works on brain problems',90);

insert into doctor values('aas','asas',23,'F','asasas',7878787878,6767676766,'sdsdfsdf','sdfdsf','sdfsdfs','sdfsdfs','reewr','ewrewr',666666,'dsd','dsadad',90,'www',1);
insert into doctor values('aas','asas',23,'F','asasas',7878787878,8888888888,'sdsdfsdf','sdfdsf','sdfsdfs','sdfsdfs','reewr','ewrewr',666666,'dsd','dsadad',90,'www',1);
insert into doctor values('Govind','Malai',23,'M','asasas',7878787878,8888888888,'sdsdfsdf','sdfdsf','sdfsdfs','sdfsdfs','reewr','ewrewr',666666,'dsd','Surgeon',90,'www',2);

insert into appointment values('PAT001','DOC001',1,'10/25/2019','Not Approved');

select do.do_id,do.do_first_name,ap.ap_date,ap.ap_status from [doctor] as do inner join [appointment] as ap on do.do_id = ap.ap_do_id where ap.ap_pt_id = 'PAT001';
select pt.pt_id,pt.pt_first_name ,pt.pt_last_name ,ap.ap_date,ap.ap_status from [patient] as pt inner join [appointment] ap on pt.pt_id = ap.ap_pt_id where ap.ap_do_id = 'DOC004';

truncate table doctor;
alter table doctor drop constraint [do_ms_id_fk] ;
truncate table appointment;
alter table appointment drop constraint ap_do_id_fk ;
alter table appointment drop constraint [ap_ms_id_fk] ;
alter table appointment drop constraint ap_pt_id_fk ;
truncate table medicare_services;
alter table [dbo].[medical_test_history] drop constraint [mth_do_id_fk] ;
alter table [dbo].[medical_test_history] drop constraint [mth_ms_id_fk] ;
alter table [dbo].[medical_test_history] drop constraint [mth_pt_id_fk] ;

truncate table patient;


select * from doctor;
select * from medicare_services;

select do.do_first_name as[First Name],do.do_last_name as [Last Name],ap.ap_date as [Appointment Date],ap.ap_status as [Status] from [doctor] as do inner join [appointment] as ap on do.do_id = ap.ap_do_id where ap.ap_pt_id = 'PAT002'

alter table [patient] add pt_status varchar(10);
update [patient] set pt_status='Inactive';

alter table [doctor] add do_status varchar(10);
update [doctor] set do_status='Inactive';

alter table [patient] alter column pt_report_status varchar(20);
update [patient] set pt_report_status='Unavailable';