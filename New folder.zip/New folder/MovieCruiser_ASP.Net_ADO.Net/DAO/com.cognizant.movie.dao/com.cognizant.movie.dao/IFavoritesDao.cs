﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;

namespace com.cognizant.movie.dao {
    interface IFavoritesDao {
        void AddFavorite(long userId,long favoriteId);
        Favorites GetAllFavorites(long userId);
        void RemoveFavorite(long userId,long favoriteId);
    }
}
