﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace com.cognizant.movie.dao {
    class ConnectionHandler {
        static string _connectionVariable = ConfigurationManager.ConnectionStrings["db_connection"].ToString();

        public static string ConnectionVariable {
            get {
                return _connectionVariable;
            }
        }
    }
}
