﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;
using System.Data;
using System.Data.SqlClient;

namespace com.cognizant.movie.dao {
    public class MovieDaoSqlImpl : IMovieDao {
        static string _callConnection = ConnectionHandler.ConnectionVariable;
        static string _getDataAdmin = "select * from movie as mv;";
        static string _getDataCustomer = "select * from movie as mv where mv.mv_active = 'Yes' and mv.mv_date_of_launch > GETDATE();";
        static string _getMovieById = "select * from movie as mv where mv.mv_id = @movieId;";
        static string _updateMovie = "update movie set mv_title = @title,mv_budget = @budget,mv_active = @active,mv_date_of_launch = @dateOfLaunch,mv_genre = @genre,mv_has_teaser = @hasTeaser where mv_id = @movieId;";

        public Movie GetMovie(long movieId) {
            Movie movie = new Movie();
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _getMovieById
                };
                sqlCommand.Parameters.Add("@movieId", SqlDbType.Int).Value = movieId;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read()) {
                    movie.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("mv_id")));
                    movie.Title = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_title")));
                    movie.Budget = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal("mv_budget")));
                    movie.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_active"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    movie.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal("mv_date_of_launch")));
                    movie.Genre = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_genre")));
                    movie.HasTeaser = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_has_teaser"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);
                }
            }
            return movie;
        }

        public List<Movie> GetMovieListAdmin() {
            List<Movie> movieList = new List<Movie>();
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _getDataAdmin
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read()) {
                    Movie movie = new Movie();
                    movie.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("mv_id")));
                    movie.Title = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_title")));
                    movie.Budget = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal("mv_budget")));
                    movie.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_active"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    movie.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal("mv_date_of_launch")));
                    movie.Genre = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_genre")));
                    movie.HasTeaser = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_has_teaser"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    movieList.Add(movie);
                }
            }

            return movieList;
        }

        public List<Movie> GetMovieListCustomer() {
            List<Movie> movieList = new List<Movie>();
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _getDataCustomer
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read()) {
                    Movie movie = new Movie();
                    movie.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("mv_id")));
                    movie.Title = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_title")));
                    movie.Budget = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal("mv_budget")));
                    movie.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_active"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    movie.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal("mv_date_of_launch")));
                    movie.Genre = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_genre")));
                    movie.HasTeaser = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_has_teaser"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    movieList.Add(movie);
                }
            }

            return movieList;
        }

        public void ModifyMovie(Movie movie) {
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _updateMovie
                };

                sqlCommand.Parameters.Add("@title", SqlDbType.VarChar).Value = movie.Title;
                sqlCommand.Parameters.Add("@budget", SqlDbType.Decimal).Value = movie.Budget;
                sqlCommand.Parameters.Add("@active", SqlDbType.VarChar).Value = (movie.Active == true) ? "Yes" : "No";
                sqlCommand.Parameters.Add("@dateOfLaunch", SqlDbType.Date).Value = movie.DateOfLaunch;
                sqlCommand.Parameters.Add("@genre", SqlDbType.VarChar).Value = movie.Genre;
                sqlCommand.Parameters.Add("@hasTeaser", SqlDbType.VarChar).Value = (movie.HasTeaser == true) ? "Yes" : "No";
                sqlCommand.Parameters.Add("@movieId", SqlDbType.Int).Value = movie.Id;

                sqlCommand.ExecuteNonQuery();
            }
        }
    }
}
