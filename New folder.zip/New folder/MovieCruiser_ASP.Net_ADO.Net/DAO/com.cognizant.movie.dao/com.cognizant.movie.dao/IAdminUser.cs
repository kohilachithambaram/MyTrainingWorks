﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;

namespace com.cognizant.movie.dao
{
    interface IAdminUser
    {
        int UserRegistration(string name, string password, long phone);
        int UserLogin(int userId, string password);
        int AdminLogin(int adminId, string password);
        List<User> DisplayUser();
        User DisplaySpecificUser(string password);
        User DisplaySpecificUserById(int id);
        int EditUserInfo(string status, int userId);
    }
}
