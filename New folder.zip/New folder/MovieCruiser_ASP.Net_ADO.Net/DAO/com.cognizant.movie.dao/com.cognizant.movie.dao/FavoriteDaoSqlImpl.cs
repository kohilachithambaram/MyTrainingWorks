﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;
using System.Data;
using System.Data.SqlClient;

namespace com.cognizant.movie.dao {
    public class FavoriteDaoSqlImpl : IFavoritesDao {
        static string _callConnection = ConnectionHandler.ConnectionVariable;
        public static string _addFavoriteData = "insert into favorite values(@userId,@movieId);";
        public static string _getAllFavoriteMovies = "select * from movie as mv inner join favorite fv on mv.mv_id = fv.fv_mv_id where fv.fv_us_id = @userId;";
        public static string _countTotal = "select sum(mv.mv_budget) as Total from movie as mv inner join favorite fv on mv.mv_id = fv.fv_mv_id where fv.fv_us_id = @userId;";
        public static string _deleteMovie = "delete from favorite where fv_us_id = @userId and fv_mv_id = @movieId;";

        public void AddFavorite(long userId, long favoriteId) {
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _addFavoriteData
                };

                sqlCommand.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                sqlCommand.Parameters.Add("@movieId", SqlDbType.Int).Value = favoriteId;

                sqlCommand.ExecuteNonQuery();
            }
        }

        public Favorites GetAllFavorites(long userId) {
            Favorites favorites = new Favorites();
            List<Movie> movieList = new List<Movie>();

            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _getAllFavoriteMovies
                };

                sqlCommand.Parameters.Add("@userId", SqlDbType.Int).Value = userId;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                int count = 0;

                while (dataReader.Read()) {
                    Movie movie = new Movie();
                    movie.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("mv_id")));
                    movie.Title = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_title")));
                    movie.Budget = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal("mv_budget")));
                    movie.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_active"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    movie.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal("mv_date_of_launch")));
                    movie.Genre = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_genre")));
                    movie.HasTeaser = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_has_teaser"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    count++;
                    movieList.Add(movie);
                }
                
                if (count == 0) {
                    throw new FavoriteEmptyException("Exception:No items in Favorite");
                }

                favorites.MovieList = movieList;
                dataReader.Close();

                SqlCommand sqlCommand1 = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _countTotal
                };

                sqlCommand1.Parameters.Add("@userId", SqlDbType.Int).Value = userId;

                SqlDataReader dataReader1 = sqlCommand1.ExecuteReader();

                while (dataReader1.Read()) {
                    favorites.Total = Convert.ToDouble(dataReader1.GetValue(dataReader1.GetOrdinal("Total")));
                }
            }

            return favorites;
        }

        public void RemoveFavorite(long userId, long favoriteId) {
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _deleteMovie
                };

                sqlCommand.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                sqlCommand.Parameters.Add("@movieId", SqlDbType.Int).Value = favoriteId;

                sqlCommand.ExecuteNonQuery();
            }
        }
    }
}
