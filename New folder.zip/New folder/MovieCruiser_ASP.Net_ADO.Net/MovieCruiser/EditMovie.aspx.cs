﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.util;
using com.cognizant.movie.model;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            lblId.Text = Request.QueryString["movieId"].ToString();
            ddlGenre.Items.Add("Select Movie");
            ddlGenre.Items.Add("Action");
            ddlGenre.Items.Add("Adventure");
            ddlGenre.Items.Add("Animation");
            ddlGenre.Items.Add("Horror");
            ddlGenre.Items.Add("Comedy");

            MovieDaoSqlImpl movieDao = new MovieDaoSqlImpl();
            if (lblId.Text != null || lblId.Text != "") {
                Movie movie = movieDao.GetMovie(long.Parse(lblId.Text));
                txtTitle.Text = movie.Title;
                double budget = movie.Budget;
                txtBudget.Text = budget.ToString();
                txtDateOfLaunch.Text = movie.DateOfLaunch.ToString("dd/MM/yyyy");
                if (movie.Active == true) {
                    radioActive.Checked = true;
                }
                else {
                    radioInactive.Checked = true;
                }
                chkHasTeaser.Checked = movie.HasTeaser;
                ddlGenre.SelectedValue = movie.Genre;
            }
        }
    }

    protected void ButtonSaveClick(object sender, EventArgs e) {
        MovieDaoSqlImpl movieDao = new MovieDaoSqlImpl();
        Movie movie = new Movie();
        movie.Id = long.Parse(lblId.Text);
        movie.Title = txtTitle.Text;
        movie.Budget = long.Parse(txtBudget.Text);
        movie.DateOfLaunch = DateUtil.convertToDate(txtDateOfLaunch.Text);
        movie.Genre = ddlGenre.SelectedItem.Text;
        if (radioActive.Checked == true) {
            radioInactive.Checked = false;
            movie.Active = true;
        }
        else {
            radioInactive.Checked = true;
            movie.Active = false;
        }
        if (chkHasTeaser.Checked == true) {
            movie.HasTeaser = true;
        }
        else {
            movie.HasTeaser = false;
        }
        movieDao.ModifyMovie(movie);
        Response.Redirect("EditMovieStatus.aspx");
    }

    protected void RadioActiveCheckedChanged(object sender, EventArgs e) {
        if (radioActive.Checked == true) {
            radioInactive.Checked = false;
        }
    }

    protected void RadioInactiveCheckedChanged(object sender, EventArgs e) {
        if (radioInactive.Checked == true) {
            radioActive.Checked = false;
        }
    }
}