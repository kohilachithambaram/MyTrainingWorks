﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                lblPassword.Text = Session["PasswordInfo"].ToString();
                if (lblPassword.Text != "" || lblPassword.Text != null)
                {
                    AdminUserBL admin = new AdminUserBL();
                    User user = admin.DisplaySpecificUser(lblPassword.Text);
                    lblUserId.Text = user.UserId.ToString();
                }
            }
        }
        catch (Exception ex)
        {

            Console.WriteLine(ex.Message);
        }
    }
}