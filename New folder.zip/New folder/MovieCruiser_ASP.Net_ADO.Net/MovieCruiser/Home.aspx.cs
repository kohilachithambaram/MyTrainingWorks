﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            adminPanel.Visible = false;
            userPanel.Visible = false;
            lblMessage.Visible = false;
        }
    }

    protected void radioAdmin_CheckedChanged(object sender, EventArgs e)
    {
        if (radioAdmin.Checked == true)
        {
            userPanel.Visible = false;
            radioUser.Checked = false;
            adminPanel.Visible = true;
        }
    }

    protected void radioUser_CheckedChanged(object sender, EventArgs e)
    {
        if (radioUser.Checked == true)
        {
            userPanel.Visible = true;
            radioAdmin.Checked = false;
            adminPanel.Visible = false;
        }
    }


    protected void btnLogin_Click(object sender, EventArgs e)
    {
        AdminUserBL admin = new AdminUserBL();
        int result = admin.AdminLogin(int.Parse(txtAdminId.Text), txtAdminPassword.Text);
        if (result > 0) // ie adminId and Password matches
        {
            Session["adminId"] = txtAdminId.Text;
            Response.Write("<script>alert('Welcome Admin');window.location.href='AdminProcess.aspx'</script>");
        }
        else //ie userId and Password is not found
        {
            Response.Write("<script>alert('Invalid Credentials.. Try again')</script>");
            //clearing old contents from text boxes to write credentials again
            txtAdminId.Text = "";
            txtAdminPassword.Text = "";
            //Position write cursor automatically on adminId text box
            txtAdminId.Focus();
        }

    }

    protected void btnUserLogin_Click(object sender, EventArgs e)
    {
        AdminUserBL admin = new AdminUserBL();
        int result = admin.UserLogin(int.Parse(txtUserId.Text), txtUserPassword.Text);
        if (result == 1)
        {
            lblMessage.Visible = false;
            lblMessage.Text = "";
            Session["userId"] = txtUserId.Text;
            Response.Write("<script>alert('Welcome User');window.location.href='MovieListCustomer.aspx'</script>");
        }
        if (result == 2)
        {
            lblMessage.Visible = true;
            lblMessage.Text = "User Status is Inactive..Try after sometime";
        }
        if (result == 3)
        {
            lblMessage.Visible = true;
            lblMessage.Text = "Invalid Credentials..Try again";
            //clearing old contents from text boxes to write credentials again
            txtUserId.Text = "";
            txtUserPassword.Text = "";
            //Position write cursor automatically on adminId text box
            txtUserId.Focus();
        }
    }
}