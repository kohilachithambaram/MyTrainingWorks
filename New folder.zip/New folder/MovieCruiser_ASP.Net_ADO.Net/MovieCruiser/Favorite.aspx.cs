﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;
using System.Globalization;
using System.Threading;

public partial class _Default : System.Web.UI.Page {
    FavoriteDaoSqlImpl favoriteDao = new FavoriteDaoSqlImpl();
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            lblUserId.Text = Session["userId"].ToString();
            lblMessage.Text = "";
            DisplayData();
        }
    }

    protected void GridFavoriteDeleteButtonClick(object sender, GridViewCommandEventArgs e) {
        int rowIndex = int.Parse(e.CommandArgument.ToString());
        string movieId = gridFavorite.Rows[rowIndex].Cells[0].Text;
        favoriteDao.RemoveFavorite(long.Parse(lblUserId.Text), long.Parse(movieId));
        lblMessage.Text = "Movie Removed from Favorites Successfully";
    }

    protected void DisplayDataAfterDelete(object sender, GridViewDeleteEventArgs e) {
        DisplayData();
    }

    protected void DisplayData() {
        try {
            gridFavorite.DataSource = favoriteDao.GetAllFavorites(long.Parse(lblUserId.Text)).MovieList;
            gridFavorite.DataBind();
            TotalPrice();
        }
        catch (FavoriteEmptyException) {

            Response.Redirect("FavoriteEmpty.aspx");
        }
    }

    protected void TotalPrice() {
        FavoriteDaoSqlImpl favoriteDao = new FavoriteDaoSqlImpl();
        Favorites favorite = favoriteDao.GetAllFavorites(long.Parse(lblUserId.Text));
        lblTotalPrice.Text = "$" + favorite.Total.ToString();
    }


    protected void GridMovieCustomerRowDataBound(object sender, GridViewRowEventArgs e) {
        if (e.Row.Cells[2].Text == "True") {
            e.Row.Cells[2].Text = "Yes";
        }
        if (e.Row.Cells[2].Text == "False") {
            e.Row.Cells[2].Text = "No";
        }
        double f;
        if (double.TryParse(e.Row.Cells[3].Text, out f))
        {
            e.Row.Cells[3].Text = "$ &nbsp" + f.ToString("N0");
        }
    }
}