﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;
using System.Globalization;
using System.Threading;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            lblUserId.Text = Session["userId"].ToString();
            DisplayMoviesCustomer();
        }
    }

    protected void GridMovieAddButtonClick(object sender, GridViewCommandEventArgs e) {
        int gridViewRowIndex = int.Parse(e.CommandArgument.ToString());
        string movieId = gridMovie.Rows[gridViewRowIndex].Cells[0].Text;
        Response.Redirect("AddToFavorite.aspx?movieId=" + movieId);
    }

    protected void DisplayMoviesCustomer() {
        MovieDaoSqlImpl movieDao = new MovieDaoSqlImpl();
        List<Movie> movieList = movieDao.GetMovieListCustomer();
        gridMovie.DataSource = movieList;
        gridMovie.DataBind();
    }

    protected void GridMovieCustomerRowDataBound(object sender, GridViewRowEventArgs e) {
        if (e.Row.Cells[3].Text == "True") {
            e.Row.Cells[3].Text = "Yes";
        }
        if (e.Row.Cells[3].Text == "False") {
            e.Row.Cells[3].Text = "No";
        }
        if (e.Row.Cells[6].Text == "True") {
            e.Row.Cells[6].Text = "Yes";
        }
        if (e.Row.Cells[6].Text == "False") {
            e.Row.Cells[6].Text = "No";
        }
        double f;
        if (double.TryParse(e.Row.Cells[2].Text, out f))
        {
            e.Row.Cells[2].Text = "$ &nbsp;" + f.ToString("N0");
        }
    }
}