﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click1(object sender, EventArgs e)
    {
        try
        {
            AdminUserBL admin = new AdminUserBL();
            int result = admin.UserRegistration(txtName.Text, txtPassword.Text, long.Parse(txtPhone.Text));
            if (result > 0)
            {
                Session["PasswordInfo"] = txtPassword.Text;
                Response.Redirect("RegistrationSuccessInfo.aspx");
            }
            else
            {
                throw new Exception();
            }
        }
        catch (Exception ex)
        {

            Response.Write("<h2 style = 'color:red;'>Same Password Exist</h2>");
        }
    }
}