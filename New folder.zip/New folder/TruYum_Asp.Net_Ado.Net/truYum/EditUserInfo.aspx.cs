﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblUserId.Text = Request.QueryString["UserId"].ToString();
            if (lblUserId.Text != null || lblUserId.Text != "")
            {
                AdminUserBL admin = new AdminUserBL();
                User user = admin.DisplaySpecificUserById(int.Parse(lblUserId.Text));

                lblPassword.Text = user.Password;
                lblStatus.Text = user.ActivationStatus;

                if (user.ActivationStatus.Equals("yes", StringComparison.InvariantCultureIgnoreCase))
                {
                    chkStatus.Checked = true;
                }
                else
                {
                    chkStatus.Checked = false;
                }
            }
        }
    }


    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            AdminUserBL admin = new AdminUserBL();
            int result = admin.EditUserInfo(lblStatus.Text, int.Parse(lblUserId.Text));
            if (result > 0) //update successful
            {
                Response.Write("<script>alert('Update Completed');window.location.href='AdminProcess.aspx'</script>");
            }
            else
            {
                throw new Exception();
            }
        }
        catch (Exception ex)
        {

            Response.Write(ex.Message);
        }
    }

    protected void chkStatus_CheckedChanged(object sender, EventArgs e)
    {
        if(chkStatus.Checked == true)
        {
            lblStatus.Text = "Yes";
        }
        else
        {
            lblStatus.Text = "No";
        }
    }
}