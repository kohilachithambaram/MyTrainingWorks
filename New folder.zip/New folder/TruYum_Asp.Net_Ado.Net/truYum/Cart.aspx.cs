﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;
using System.Globalization;
using System.Threading;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
         if(!IsPostBack)
        {
            lblMessage.Text = "";
            lblUserId.Text = Session["userId"].ToString();
            Displaydata();
        }
    }

    protected void gridCart_DeleteButtonClick(object sender, GridViewCommandEventArgs e)
    {
        CartDaoSQL cartDao = new CartDaoSQL();
        //Delete the data when user clicks thre delete button
        //Find the row index that is from which row u have click the button
        int rowindex = int.Parse(e.CommandArgument.ToString());
        string itemId = gridCart.Rows[rowindex].Cells[0].Text;
        cartDao.RemoveCartItem(long.Parse(lblUserId.Text),long.Parse(itemId));
        lblMessage.Text = "Item Removed from Cart Successfully";
    }

    protected void Display_Data_After_Delete(object sender, GridViewDeleteEventArgs e)
    {
        //display data in grid after deletion process
        Displaydata();

    }

    protected void Displaydata()
    {
        CartDaoSQL cartDao = new CartDaoSQL();
        try
        {
            gridCart.DataSource = cartDao.GetAllCartItems(long.Parse(lblUserId.Text)).MenuItemList;
            gridCart.DataBind();
            TotalPrice();
        }
        catch (CartEmptyException)
        {

            Response.Redirect("CartEmpty.aspx");
        }
    }
    protected void TotalPrice()
    {
        CartDaoSQL cartDao = new CartDaoSQL();
        Cart cart = cartDao.GetAllCartItems(long.Parse(lblUserId.Text));
        lblTotalPrice.Text = "₹"+cart.Total.ToString();

        
    }
    protected override void InitializeCulture()
    {
        CultureInfo ci = new CultureInfo("en-IN");
        ci.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = ci;

        base.InitializeCulture();
    }

    protected void GridMenuItemRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.Cells[2].Text == "True")
        {
            e.Row.Cells[2].Text = "Yes";
        }
        if (e.Row.Cells[2].Text == "False")
        {
            e.Row.Cells[2].Text = "No";
        }
    }
}