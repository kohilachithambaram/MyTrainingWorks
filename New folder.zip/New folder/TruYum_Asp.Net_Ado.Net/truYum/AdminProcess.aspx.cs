﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Dao;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            lblAdminId.Text = Session["adminId"].ToString();
            gridCustomer.Visible = false;
            DisplayData();
        }
    }

    protected void radioEditCustomer_CheckedChanged(object sender, EventArgs e)
    {
        if(radioEditCustomer.Checked == true)
        {
            radioMenuItem.Checked = false;
            gridCustomer.Visible = true;
        }
    }

    protected void radioMenuItem_CheckedChanged(object sender, EventArgs e)
    {
        if (radioMenuItem.Checked == true)
        {
            radioEditCustomer.Checked = false;
            Response.Redirect("MenuItemListAdminItem.aspx");
        }
    }

    protected void EditCustomerData(object sender, GridViewEditEventArgs e)
    {
        //Create a row in grid for seraching the edition

        GridViewRow row = gridCustomer.Rows[e.NewEditIndex];
        string userId = row.Cells[0].Text;
        Response.Redirect("EditUserInfo.aspx?UserId=" + userId);
    }

    protected void DisplayData()
    {
        AdminUserBL adminUser = new AdminUserBL();
        List<User> userList = adminUser.DisplayUser();
        gridCustomer.DataSource = userList;
        gridCustomer.DataBind();
    }
}