﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
//namespaces for model,dao,util
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Utility;

namespace AdminUserTest
{
    [TestClass]
    public class truYumTestActors
    {
       /* [TestMethod]
        public void TestUserRegistration()
        {
            AdminUserBL admin = new AdminUserBL();
            int result = admin.UserRegistration("Kohila","koki@123",9788745210);
            //test if result > 0 then insert success else failure
            Assert.AreEqual(1,result); 
        }*/

        [TestMethod]
        public void TestDisplayUserByPassword()
        {
            AdminUserBL admin = new AdminUserBL();
            User user = admin.DisplaySpecificUser("fgfgfg");
            bool result = false;
            if(user != null)//ie user found by password
            {
                result = true;
            }
            Assert.AreEqual(true,result);
        }
    }
}
