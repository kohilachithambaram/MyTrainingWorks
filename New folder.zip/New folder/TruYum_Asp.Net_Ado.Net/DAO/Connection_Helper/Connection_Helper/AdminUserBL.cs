﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
    public class AdminUserBL : IAdminUser
    {
        static string _callConnection = ConnectionHandler.ConnectionVariable;
        static string _registerUser = "insert into [user] values(@name,@password,@phone,@active);";
        static string _displayFilteredUser = "select * from [user] (nolock) where us_password = @password;";
        static string _lodinAdmin = "select * from admin (nolock);";
        static string _userDetails = "select * from [user] (nolock);";
        static string _displayFilteredUserById = "select * from [user] (nolock) where us_id = @id;";
        static string _updateUser = "update [user] set us_active = @active where us_id = @id;";
        public int AdminLogin(int adminId, string password)
        {
            int logResult = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _lodinAdmin
                };
                //Read data one by one from the table and match with user supplied username and password
                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while(dataReader.Read())
                {
                    if(Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("ad_id"))).Equals(adminId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("ad_password"))).Equals(password))
                    {
                        logResult = 1;
                        break;
                    }
                }
            }
            return logResult;
        }

        public User DisplaySpecificUser(string password)
        {
            User user = new User();
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _displayFilteredUser
                };
                sqlCommand.Parameters.Add("@password", SqlDbType.VarChar).Value = password;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    user.UserId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("us_id")));
                    user.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_name")));
                    user.Password = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_password")));
                    user.Phone = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal("us_phone")));
                    user.ActivationStatus = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_active")));
                }
            }
            return user;
        }

        public List<User> DisplayUser()
        {
            List<User> userList = new List<User>();


            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _userDetails
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    User user = new User();
                    user.UserId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("us_id")));
                    user.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_name")));
                    user.Password = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_password")));
                    user.Phone = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal("us_phone")));
                    user.ActivationStatus = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_active")));
                    
                    userList.Add(user);
                }
            }
            return userList;
        }

        public int EditUserInfo(string status, int userId)
        {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _updateUser
                };
                sqlCommand.Parameters.Add("@active",SqlDbType.VarChar).Value = status;
                sqlCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = userId;
                result = sqlCommand.ExecuteNonQuery();
            }
            return result; 
        }

        public int UserLogin(int userId, string password)
        {
            int logResult = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _userDetails
                };
                //Read data one by one from the table and match with user supplied username and password
                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    //Userid and Password is found,Also status is active Login
                    if (Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("us_id"))).Equals(userId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_password"))).Equals(password)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_active"))).Equals("Yes",StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 1;
                        break;
                    }
                    //Userid and Password is found,Also status is inactive Don't Login
                    else if (Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("us_id"))).Equals(userId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_password"))).Equals(password)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_active"))).Equals("No", StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 2;
                        break;
                    }
                    //Userid and Password is not found
                    else
                    {
                        logResult = 3;
                    }
                }
            }
            return logResult;
        }

        public int UserRegistration(string name, string password, long phone)
        {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _registerUser
                };

                sqlCommand.Parameters.Add("@name", SqlDbType.VarChar).Value = name;
                sqlCommand.Parameters.Add("@password", SqlDbType.VarChar).Value = password;
                sqlCommand.Parameters.Add("@phone", SqlDbType.BigInt).Value = phone;
                sqlCommand.Parameters.Add("@active", SqlDbType.VarChar).Value = "No";

                result = sqlCommand.ExecuteNonQuery();

            }
            return result;
        }

        public User DisplaySpecificUserById(int id)
        {
            User user = new User();
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _displayFilteredUserById
                };
                sqlCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = id;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    user.UserId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("us_id")));
                    user.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_name")));
                    user.Password = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_password")));
                    user.Phone = Convert.ToInt64(dataReader.GetValue(dataReader.GetOrdinal("us_phone")));
                    user.ActivationStatus = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("us_active")));
                }
            }
            return user;
        }

        
    }
}
