﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Truyum.Dao
{
    public static class Queries
    {
        public static string _getDataAdmin = "select * from [dbo].[menu_item] as me (nolock);";
        public static string _getDataCustomer = "select * from [dbo].[menu_item] as me (nolock) where me.me_date_of_launch > GETDATE() and me.me_active = 'Yes';";
        public static string _getItemById = "select * from [dbo].[menu_item] as me (nolock) where me.me_id = @id ;";
        public static string _updateItem = "update [dbo].[menu_item] set me_name = @name, me_price = @price, me_active = @active, me_date_of_launch = @dateOfLaunch, me_category = @category, me_free_delivery = @freeDelivery where me_id = @id;";

        public static string _addCartData = "insert into [dbo].[cart] values(@userId,@menuId);";
        public static string _getAllCartItems = "select * from [dbo].[menu_item] as me (nolock) join [dbo].[cart] as ct (nolock) on me.me_id = ct.ct_me_id where ct.ct_us_id = @userId;";
        public static string _countTotal = "select sum(me.me_price) as Total from [dbo].[menu_item] as me (nolock) join [dbo].[cart] as ct (nolock) on me.me_id = ct.ct_me_id where ct.ct_us_id = @userId;";
        public static string _deleteItem = "delete from [dbo].[cart] where ct_us_id = @userId and ct_me_id = @menuId;";
    }
}
