﻿using System;
using System.Collections.Generic;
//class file
//namespace
using System.Data;
using System.Data.SqlClient;
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
    public class MenuItemDaoSQL:IMenuItemDao
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        
        /// <summary>
        /// This method displays the list of menu items for Admin
        /// </summary>
        /// <returns>returns the list</returns>
        public List<MenuItem> GetMenuItemListAdmin()
        {
            List<MenuItem> menuList = new List<MenuItem>();
            

            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._getDataAdmin
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while(dataReader.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.id)));
                    menu.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.name)));
                    menu.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.price)));
                    menu.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.active))).Equals(Constants.yes,StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menu.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.dateOfLaunch)));
                    menu.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.category)));
                    menu.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.freeDelivery))).Equals(Constants.yes, StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                }
            }

            return menuList;
        }

        /// <summary>
        /// This method displays the list of menu items for Customer
        /// </summary>
        /// <returns>returns the list</returns>
        public List<MenuItem> GetMenuItemListCustomer()
        {
            List<MenuItem> menuList = new List<MenuItem>();


            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._getDataCustomer
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.id)));
                    menu.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.name)));
                    menu.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.price)));
                    menu.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.active))).Equals(Constants.yes, StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menu.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.dateOfLaunch)));
                    menu.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.category)));
                    menu.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.freeDelivery))).Equals(Constants.yes, StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                }
            }
            return menuList;
        }

        /// <summary>
        /// This method updates the items
        /// </summary>
        /// <param name="menuItem"></param>
        public void ModifyMenuItem(MenuItem menuItem)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._updateItem
                };

                sqlCommand.Parameters.Add(Constants.attributeName,SqlDbType.VarChar).Value = menuItem.Name;
                sqlCommand.Parameters.Add(Constants.attributePrice, SqlDbType.Decimal).Value = menuItem.Price;
                sqlCommand.Parameters.Add(Constants.attributeActive, SqlDbType.VarChar).Value = (menuItem.Active == true) ? Constants.yes : Constants.no;
                sqlCommand.Parameters.Add(Constants.attributeDateOfLaunch, SqlDbType.Date).Value = menuItem.DateOfLaunch;
                sqlCommand.Parameters.Add(Constants.attributeCategory, SqlDbType.VarChar).Value = menuItem.Category;
                sqlCommand.Parameters.Add(Constants.attributeFreeDelivery, SqlDbType.VarChar).Value = (menuItem.FreeDelivery == true) ? Constants.yes : Constants.no;
                sqlCommand.Parameters.Add(Constants.attributeId, SqlDbType.Int).Value = menuItem.Id;

                sqlCommand.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// This method displays the item based on the id selected
        /// </summary>
        /// <param name="menuItemId"></param>
        /// <returns>returns a single data of item selected</returns>
        public MenuItem GetMenuItem(long menuItemId)
        {
            MenuItem menuItem = new MenuItem();
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._getItemById
                };
                sqlCommand.Parameters.Add(Constants.attributeId,SqlDbType.Int).Value = menuItemId;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    menuItem.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.id)));
                    menuItem.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.name)));
                    menuItem.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.price)));
                    menuItem.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.active))).Equals(Constants.yes, StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menuItem.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.dateOfLaunch)));
                    menuItem.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.category)));
                    menuItem.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.freeDelivery))).Equals(Constants.yes, StringComparison.InvariantCultureIgnoreCase) ? true : false);
                }
            }
            return menuItem;
        }
    }
}
