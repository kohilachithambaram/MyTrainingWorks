﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Truyum.Dao
{
    public static class Constants
    {
        public static string id = "me_id";
        public static string name = "me_name";
        public static string price = "me_price";
        public static string active = "me_active";
        public static string dateOfLaunch = "me_date_of_launch";
        public static string category = "me_category";
        public static string freeDelivery = "me_free_delivery";
        public static string yes = "Yes";
        public static string no = "No";
        public static string total = "Total";

        public static string attributeName = "@name";
        public static string attributePrice = "@price";
        public static string attributeActive = "@active";
        public static string attributeDateOfLaunch = "@dateOfLaunch";
        public static string attributeCategory = "@category";
        public static string attributeFreeDelivery = "@freeDelivery";
        public static string attributeId = "@id";
        public static string attributeMenuId = "@menuId";
        public static string attributeUserId = "@userId";
    }
}
