﻿using System;
using System.Collections.Generic;
//class file
//namespace
using System.Data;
using System.Data.SqlClient;
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
    public class CartDaoSQL:ICartDao
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        
        /// <summary>
        /// This method inserts the data to the cart table
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="productId"></param>
        public void AddCartItem(long userId,long productId)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._addCartData
                };

                sqlCommand.Parameters.Add(Constants.attributeUserId,SqlDbType.Int).Value = userId;
                sqlCommand.Parameters.Add(Constants.attributeMenuId, SqlDbType.Int).Value = productId;

                sqlCommand.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// This method displays the cart items and the total
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public Cart GetAllCartItems(long userId)
        {
            Cart cart = new Cart();
            List<MenuItem> menuList = new List<MenuItem>();

            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._getAllCartItems
                };

                sqlCommand.Parameters.Add(Constants.attributeUserId, SqlDbType.Int).Value = userId;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                int count = 0;

                while (dataReader.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.id)));
                    menu.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.name)));
                    menu.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.price)));
                    menu.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.active))).Equals(Constants.yes, StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menu.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.dateOfLaunch)));
                    menu.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.category)));
                    menu.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.freeDelivery))).Equals(Constants.yes, StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    count++;
                    menuList.Add(menu);
                }
                //dataReader.Close();
                if(count == 0) // ie no item in the cart
                {
                    throw new CartEmptyException("Exception:No item in the Cart");
                }

                cart.MenuItemList = menuList;
                dataReader.Close();

                SqlCommand sqlCommand1 = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._countTotal
                };

                sqlCommand1.Parameters.Add(Constants.attributeUserId, SqlDbType.Int).Value = userId;

                SqlDataReader dataReader1 = sqlCommand1.ExecuteReader();

                while(dataReader1.Read())
                {
                    cart.Total = Convert.ToDouble(dataReader1.GetValue(dataReader1.GetOrdinal(Constants.total)));
                }

            }

            return cart;
        }

        /// <summary>
        /// this method removes the item from the cart 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="productId"></param>

        public void RemoveCartItem(long userId,long productId)
        {
            using (SqlConnection connection = new SqlConnection(callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = Queries._deleteItem
                };

                sqlCommand.Parameters.Add(Constants.attributeUserId, SqlDbType.Int).Value = userId;
                sqlCommand.Parameters.Add(Constants.attributeMenuId, SqlDbType.Int).Value = productId;

                sqlCommand.ExecuteNonQuery();
            }
        }
    }
}
