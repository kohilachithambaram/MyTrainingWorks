﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
//class library file

namespace Com.Cognizant.Truyum.Dao
{
    public class ConnectionHandler
    {
        static string variable = ConfigurationManager.ConnectionStrings["db_connection"].ToString();
        //ConfigurationManager.ConnectionStrings[] contains the connection variable
        public static string ConnectionVariable
        {
            get
            {
                return variable;
            }
        }
    }
}
